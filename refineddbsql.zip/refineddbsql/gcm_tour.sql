-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: gcm
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tour`
--

DROP TABLE IF EXISTS `tour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tour` (
  `tour_id` bigint NOT NULL AUTO_INCREMENT,
  `city_id` bigint NOT NULL,
  `tour_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `general_desc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` double DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `map_id` bigint DEFAULT NULL,
  PRIMARY KEY (`tour_id`),
  UNIQUE KEY `UK5hl84lkr4i9g50adgrkupaoir` (`map_id`),
  KEY `idx_tour_city` (`city_id`),
  CONSTRAINT `fk_tour_city` FOREIGN KEY (`city_id`) REFERENCES `city` (`city_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FKmam6jrfilwf3v8q8694r59xh1` FOREIGN KEY (`map_id`) REFERENCES `map` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tour`
--

LOCK TABLES `tour` WRITE;
/*!40000 ALTER TABLE `tour` DISABLE KEYS */;
INSERT INTO `tour` VALUES (12,7,'Old Town & Heritage','A heritage tour through Beersheba’s Old City, exploring its origins, historic buildings, and early urban development. The route focuses on the city’s transformation over time.',5,1,'2025-12-25 09:41:32',NULL),(13,7,'Desert Science Route','A modern tour highlighting Beersheba’s role as a center for education, science, and innovation. The route connects academic institutions, research areas, and science-focused attractions.',8,1,'2025-12-25 09:41:33',NULL),(14,7,'Negev Culture Walk','A cultural tour combining parks, art spaces, and community centers. The route reflects Beersheba’s cultural diversity and its growing urban identity in the Negev.',4,1,'2025-12-25 09:41:34',NULL),(15,8,'Coral Beach Snorkel Spots','A coastal tour along Eilat’s southern beaches, focusing on coral reefs, marine life areas, and scenic seaside stops. The tour emphasizes nature, conservation, and relaxation.',4,1,'2025-12-25 09:41:35',NULL),(16,8,'Eilat Mountains Lookouts','A desert landscape tour connecting mountain viewpoints and trail areas around Eilat. The route highlights dramatic scenery, geological features, and panoramic desert views.',7,1,'2025-12-25 09:41:36',NULL),(17,8,'Lagoon & Boardwalk','A relaxed urban-coastal tour around Eilat’s marina, lagoons, and boardwalk. The route combines leisure spots, waterfront paths, and family-friendly attractions.',4,1,'2025-12-25 09:41:37',NULL),(18,3,'Carmel Nature Trail','A nature-focused tour in the Carmel area, blending green trails, scenic lookouts, and quiet urban nature paths. Ideal for showcasing Haifa’s balance between city and landscape.',7,1,'2025-12-25 09:41:38',NULL),(19,3,'German Colony & Food','A cultural and culinary walk along the historic German Colony. The tour highlights preserved architecture, local markets, and food spots, combining history with everyday city life.',6,1,'2025-12-25 09:41:39',NULL),(20,3,'Baháʼí Gardens & Views','A visually striking tour centered around the Baháʼí Gardens and surrounding viewpoints. The route emphasizes symmetry, architecture, and sweeping views of Haifa Bay and the Mediterranean Sea.',7,1,'2025-12-25 09:41:40',NULL),(21,2,'Jaffa Ancient Port','A historical tour through Old Jaffa, combining ancient alleys, religious landmarks, and the historic port. The tour focuses on the city’s layered past, blending archaeology, culture, and seaside views.',6,1,'2025-12-25 09:41:43',NULL),(22,2,'Florentin Street Art','An urban exploration through the Florentin neighborhood, known for its street art, creative energy, and local markets. The tour highlights murals, cultural spots, and the neighborhood’s youthful, alternative spirit.',10,1,'2025-12-25 09:41:44',NULL),(23,2,'Tel Aviv Beach Vibes','A relaxed coastal tour following Tel Aviv’s famous shoreline. The route passes popular beaches, promenades, and parks, capturing the city’s vibrant seaside culture and open atmosphere.',8,1,'2025-12-25 09:41:45',NULL),(24,1,'Mount of Olives Views','A scenic tour along the Mount of Olives, offering panoramic views of the Old City and surrounding areas. The tour connects viewpoints and historic sites, emphasizing geography, spirituality, and visual storytelling.',5,1,'2025-12-25 09:41:47',NULL),(25,1,'Modern Jerusalem Walk','A lively urban tour showcasing modern Jerusalem. The route combines bustling markets, pedestrian streets, and cultural institutions, highlighting the city’s contemporary lifestyle alongside its historic character.',8,1,'2025-12-25 09:41:48',NULL),(27,1,'Old City Highlights','test',7,1,'2025-12-25 10:52:33',NULL),(28,9,'rwar','rwar',3,1,'2025-12-25 19:56:48',NULL);
/*!40000 ALTER TABLE `tour` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-26 10:30:33
