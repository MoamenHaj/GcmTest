package org.gcm.client;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import org.gcm.common.Message;
import org.gcm.common.dto.CityDto;
import org.gcm.common.dto.PoiDto;
import org.gcm.common.dto.UserDto;
import org.gcm.common.enums.MessageType;
import java.io.IOException;
import java.util.List;

public class CityPoisController {

    @FXML private Label lblCityName;
    @FXML private VBox listContainer;

    private CityDto currentCity;

    public void setCityData(CityDto city) {
        this.currentCity = city;
        if (city != null) lblCityName.setText(city.getCityName());
        loadRealPois();
    }

    private void loadRealPois() {
        new Thread(() -> {
            try {
                GcmClient.getInstance().sendRequest(new Message(MessageType.GET_CITY_POIS, currentCity.getCityId()));
                Object response = GcmClient.getInstance().waitForResponse();

                List<PoiDto> pois = null;
                if (response instanceof Message && ((Message)response).getType() == MessageType.GET_CITY_POIS_RESPONSE) {
                    pois = (List<PoiDto>) ((Message)response).getData();
                } else if (response instanceof List) {
                    pois = (List<PoiDto>) response;
                }

                if (pois != null) {
                    final List<PoiDto> finalPois = pois;
                    Platform.runLater(() -> displayPois(finalPois));
                }

            } catch (Exception e) { e.printStackTrace(); }
        }).start();
    }

    private void displayPois(List<PoiDto> pois) {
        listContainer.getChildren().clear();
        if (pois.isEmpty()) {
            listContainer.getChildren().add(new Label("No POIs found. Click '+ Add New POI'."));
        } else {
            for (PoiDto poi : pois) addPoiRow(poi);
        }
    }

    private void addPoiRow(PoiDto poi) {
        VBox card = new VBox(5);
        card.setStyle("-fx-background-color: white; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.05), 5, 0, 0, 2); -fx-background-radius: 5; -fx-padding: 15;");

        HBox top = new HBox();
        Label lblTitle = new Label(poi.getName());
        lblTitle.setStyle("-fx-font-weight: bold; -fx-font-size: 16px;");
        Region spacer = new Region(); HBox.setHgrow(spacer, Priority.ALWAYS);
        top.getChildren().addAll(lblTitle, spacer);

        Label lblDesc = new Label(poi.getDescription());
        lblDesc.setStyle("-fx-text-fill: #666;");

        HBox actions = new HBox(10);
        actions.setPadding(new Insets(10, 0, 0, 0));

        Button btnEdit = new Button("Edit");
        btnEdit.setStyle("-fx-background-color: #e3f2fd; -fx-text-fill: #2962ff; -fx-cursor: hand;");
        btnEdit.setMaxWidth(Double.MAX_VALUE); HBox.setHgrow(btnEdit, Priority.ALWAYS);
        btnEdit.setOnAction(e -> openPoiEditor(poi));

        Button btnDelete = new Button("Delete");
        btnDelete.setStyle("-fx-background-color: #ffebee; -fx-text-fill: #d32f2f; -fx-cursor: hand;");
        btnDelete.setMaxWidth(Double.MAX_VALUE); HBox.setHgrow(btnDelete, Priority.ALWAYS);
        btnDelete.setOnAction(e -> deletePoi(poi));

        actions.getChildren().addAll(btnEdit, btnDelete);
        card.getChildren().addAll(top, lblDesc, actions);
        listContainer.getChildren().add(card);
    }

    @FXML public void handleAddPoi() {
        openPoiEditor(null);
    }

    private void deletePoi(PoiDto poi) {
        new Thread(() -> {
            try {
                UserDto user = ClientSession.getInstance().getUser();

                Object[] reqData = { user.getId(), "POI", poi.getId(), "DELETE", "Request to delete POI: " + poi.getName() };

                GcmClient.getInstance().sendRequest(new Message(MessageType.WORKER_UPDATE_REQUEST, reqData));

                Platform.runLater(() -> {
                    System.out.println("Delete request sent for POI: " + poi.getName());
                });

            } catch (Exception e) { e.printStackTrace(); }
        }).start();
    }

    private void openPoiEditor(PoiDto poi) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/gcm/client/AddPoiView.fxml"));
            javafx.scene.Parent root = loader.load();

            AddPoiController controller = loader.getController();
            controller.setPoiData(currentCity, poi);

            Stage popupStage = new Stage();
            popupStage.setScene(new javafx.scene.Scene(root));
            popupStage.setTitle(poi == null ? "Add POI" : "Edit POI");

            popupStage.initModality(Modality.APPLICATION_MODAL);

            popupStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML public void handleBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/gcm/client/CityEditView.fxml"));
            javafx.scene.Parent root = loader.load();
            CityEditController controller = loader.getController();
            controller.setCityData(currentCity);
            Stage stage = (Stage) lblCityName.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) { e.printStackTrace(); }
    }
}
