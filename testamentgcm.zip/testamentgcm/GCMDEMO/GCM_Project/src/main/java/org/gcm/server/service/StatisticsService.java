package org.gcm.server.service;

import org.gcm.common.dto.DailyStatisticsDto;
import org.gcm.server.db.GcmRepository;
import org.gcm.server.entity.AppUser;
import org.hibernate.Session;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class StatisticsService {
    private static StatisticsService instance;
    private GcmRepository repository;

    private StatisticsService() { repository = GcmRepository.getInstance(); }

    public static StatisticsService getInstance() {
        if (instance == null) instance = new StatisticsService();
        return instance;
    }

    public DailyStatisticsDto getDailyStatistics(Long userId, LocalDate date) throws IllegalAccessException {

        AppUser admin = repository.findById(AppUser.class, userId);
        if (admin == null || "CUSTOMER".equals(admin.getRole())) {
            throw new IllegalAccessException("Access Denied");
        }

        try (Session session = repository.openSession()) {
            LocalDateTime start = date.atStartOfDay();
            LocalDateTime end = date.atTime(LocalTime.MAX);

            Long purchases = session.createQuery("SELECT count(p) FROM Purchase p WHERE p.purchaseDate BETWEEN :s AND :e", Long.class)
                    .setParameter("s", java.sql.Timestamp.valueOf(start))
                    .setParameter("e", java.sql.Timestamp.valueOf(end))
                    .uniqueResult();

            Long reqCreated = session.createQuery("SELECT count(r) FROM ModificationRequest r WHERE r.requestDate BETWEEN :s AND :e", Long.class)
                    .setParameter("s", java.sql.Timestamp.valueOf(start))
                    .setParameter("e", java.sql.Timestamp.valueOf(end))
                    .uniqueResult();

            Double revenue = session.createQuery("SELECT sum(t.price) FROM Purchase p, Tour t WHERE p.tourId = t.tourId AND p.purchaseDate BETWEEN :s AND :e", Double.class)
                    .setParameter("s", java.sql.Timestamp.valueOf(start))
                    .setParameter("e", java.sql.Timestamp.valueOf(end))
                    .uniqueResult();

            return new DailyStatisticsDto(date, 0, 0,
                    purchases != null ? purchases : 0,
                    reqCreated != null ? reqCreated : 0,
                    0,
                    revenue != null ? revenue : 0.0);
        }
    }
}
