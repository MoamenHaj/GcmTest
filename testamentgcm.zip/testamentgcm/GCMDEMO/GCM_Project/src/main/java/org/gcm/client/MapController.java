package org.gcm.client;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import org.gcm.common.Message;
import org.gcm.common.dto.MapResponseDto;
import org.gcm.common.dto.TourDto;
import org.gcm.common.dto.UserDto;
import org.gcm.common.enums.MessageType;

import java.io.IOException;

public class MapController {

    @FXML private Label lblTitle;
    @FXML private StackPane mapContainer;

    private MapView mapView;
    private TourDto currentTour;

    public void initialize() {
        mapView = new MapView();
        mapContainer.getChildren().add(mapView);

        mapView.prefWidthProperty().bind(mapContainer.widthProperty());
        mapView.prefHeightProperty().bind(mapContainer.heightProperty());
    }

    public void setTourData(TourDto tour) {
        this.currentTour = tour;
        lblTitle.setText("Map: " + tour.getTourName());
        loadMapData();
    }

    private void loadMapData() {
        new Thread(() -> {
            try {
                UserDto user = ClientSession.getInstance().getUser();
                Long userId = (user != null) ? user.getId() : null;

                GcmClient.getInstance().sendRequest(new Message(MessageType.GET_MAP_REQUEST, new Object[]{currentTour.getTourId(), userId}));
                Object response = GcmClient.getInstance().waitForResponse();

                if (response instanceof Message) {
                    Message msg = (Message) response;
                    if (msg.getType() == MessageType.GET_MAP_RESPONSE) {
                        MapResponseDto mapData = (MapResponseDto) msg.getData();
                        Platform.runLater(() -> {
                            if (mapData != null) {
                                System.out.println("DEBUG: MapController received " + (mapData.getPois() != null ? mapData.getPois().size() : 0) + " POIs.");
                                mapView.setPois(mapData.getPois());
                                if (mapData.getMap() != null) {
                                    mapView.setZoom(mapData.getMap().getZoom());
                                }
                            } else {
                                System.err.println("DEBUG: MapController received NULL mapData.");
                            }
                        });
                    } else if (msg.getType() == MessageType.ERROR_RESPONSE) {
                        String error = (String) msg.getData();
                        Platform.runLater(() -> showError("Access Denied: " + error));
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void showError(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setContentText(msg);
        alert.showAndWait();
        handleBack();
    }

    @FXML
    public void handleBack() {
        try {

            Stage stage = (Stage) lblTitle.getScene().getWindow();
            stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/org/gcm/client/CatalogView.fxml"))));
        } catch (IOException e) { e.printStackTrace(); }
    }
}
