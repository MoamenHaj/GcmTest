package org.gcm.client;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.gcm.common.Message;
import org.gcm.common.dto.CityDto;
import org.gcm.common.dto.TourDto;
import org.gcm.common.dto.UserDto;
import org.gcm.common.enums.MessageType;
import java.io.IOException;
import java.util.List;

public class CityToursController {

    @FXML private Label lblCityName;
    @FXML private Label lblCityDesc;
    @FXML private VBox listContainer;

    private CityDto currentCity;

    public void setCityData(CityDto city) {
        this.currentCity = city;
        lblCityName.setText(city.getCityName());
        lblCityDesc.setText(city.getDescription());

        fetchToursFromServer();
    }

    private void fetchToursFromServer() {
        new Thread(() -> {
            try {
                UserDto user = ClientSession.getInstance().getUser();
                Long userId = (user != null) ? user.getId() : null;

                System.out.println("DEBUG: Fetching tours for CityID=" + currentCity.getCityId() + ", UserID=" + userId);

                GcmClient.getInstance().sendRequest(new Message(MessageType.GET_CITY_TOURS, new Object[]{currentCity.getCityId(), userId}));

                Object response = GcmClient.getInstance().waitForResponse();

                List<TourDto> tours = null;

                if (response instanceof java.util.List) {
                    tours = (List<TourDto>) response;
                }
                else if (response instanceof Message) {
                    tours = (List<TourDto>) ((Message) response).getData();
                }

                if (tours != null) {
                    final List<TourDto> finalTours = tours;
                    Platform.runLater(() -> displayTours(finalTours));
                }

            } catch (Exception e) { e.printStackTrace(); }
        }).start();
    }

    private void displayTours(List<TourDto> tours) {
        listContainer.getChildren().clear();

        if (tours == null || tours.isEmpty()) {
            Label empty = new Label("No tours available for this city yet.");
            empty.setStyle("-fx-text-fill: #666; -fx-font-size: 14px;");
            listContainer.getChildren().add(empty);
            return;
        }

        for (TourDto tour : tours) {
            System.out.println("DEBUG: Displaying Tour: " + tour.getTourName() + ", Purchased: " + tour.isPurchased());

            VBox card = new VBox(5);
            card.setStyle("-fx-background-color: white; -fx-padding: 15; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 5, 0, 0, 2); -fx-background-radius: 5; -fx-border-color: #e0e0e0; -fx-border-radius: 5;");

            Label name = new Label(tour.getTourName() != null ? tour.getTourName() : "Unnamed Tour");
            name.setStyle("-fx-font-weight: bold; -fx-font-size: 18px; -fx-text-fill: #0d1b2a;");

            Label desc = new Label(tour.getDescription() != null ? tour.getDescription() : "No description available.");
            desc.setWrapText(true);
            desc.setStyle("-fx-text-fill: #555; -fx-font-size: 14px;");

            VBox poiBox = new VBox(2);
            poiBox.setStyle("-fx-padding: 10 0 0 0;");

            if (tour.isPurchased()) {
                int stopCount = (tour.getPoiNames() != null) ? tour.getPoiNames().size() : 0;
                Label poiHeader = new Label("Route Stops (" + stopCount + "):");
                poiHeader.setStyle("-fx-font-weight: bold; -fx-text-fill: #444; -fx-font-size: 14px;");
                poiBox.getChildren().add(poiHeader);

                if (stopCount == 0) {
                    Label noPois = new Label("  • No stops listed");
                    noPois.setStyle("-fx-font-style: italic; -fx-text-fill: #777;");
                    poiBox.getChildren().add(noPois);
                } else {
                    for (String poiName : tour.getPoiNames()) {
                        Label poiLabel = new Label("  • " + poiName);
                        poiLabel.setStyle("-fx-text-fill: #333;");
                        poiBox.getChildren().add(poiLabel);
                    }
                }

                Button btnMap = new Button("🗺 View Map");
                btnMap.setStyle("-fx-background-color: #2196f3; -fx-text-fill: white; -fx-font-weight: bold; -fx-cursor: hand; -fx-margin: 10 0 0 0;");
                btnMap.setOnAction(e -> handleViewMap(tour));
                poiBox.getChildren().add(btnMap);

            } else {

                Label lockedLabel = new Label("🔒 Purchase to view stops");
                lockedLabel.setStyle("-fx-text-fill: #d32f2f; -fx-font-style: italic;");
                poiBox.getChildren().add(lockedLabel);

                Button btnBuy = new Button("Buy Now");
                btnBuy.setStyle("-fx-background-color: #ff9800; -fx-text-fill: white; -fx-font-weight: bold; -fx-cursor: hand;");
                btnBuy.setOnAction(e -> handlePurchase(tour));
                poiBox.getChildren().add(btnBuy);
            }

            Label price = new Label("Price: $" + tour.getPrice());
            price.setStyle("-fx-text-fill: #2962ff; -fx-font-weight: bold; -fx-font-size: 16px; -fx-padding: 10 0 0 0;");

            card.getChildren().addAll(name, desc, poiBox, price);
            listContainer.getChildren().add(card);
        }
    }

    private void handlePurchase(TourDto tour) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/gcm/client/PaymentView.fxml"));
            javafx.scene.Parent root = loader.load();

            PaymentController controller = loader.getController();

            controller.setPaymentData(tour, this::fetchToursFromServer);

            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Secure Payment");
            stage.setScene(new Scene(root));
            stage.showAndWait();

        } catch (IOException e) { e.printStackTrace(); }
    }

    private void handleViewMap(TourDto tour) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/gcm/client/MapView.fxml"));
            javafx.scene.Parent root = loader.load();

            MapController controller = loader.getController();
            controller.setTourData(tour);

            Stage stage = (Stage) lblCityName.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) { e.printStackTrace(); }
    }

    @FXML
    public void handleBack() {
        try {
            Stage stage = (Stage) lblCityName.getScene().getWindow();
            stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/org/gcm/client/CatalogView.fxml"))));
        } catch (IOException e) { e.printStackTrace(); }
    }
}
