package org.gcm.client;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import javafx.geometry.Point2D;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

public final class GeoCoder {
    private static final HttpClient CLIENT = HttpClient.newHttpClient();
    private static final ObjectMapper MAPPER = new ObjectMapper();

    private static final String USER_AGENT = "GCMDemo/1.0 (moamen@example.com)";

    private GeoCoder() {}

    public static Optional<Point2D> geocode(String place) throws IOException, InterruptedException {
        if (place == null || place.isBlank()) return Optional.empty();
        String q = URLEncoder.encode(place, StandardCharsets.UTF_8);
        String url = "https://nominatim.openstreetmap.org/search?format=json&q=" + q + "&limit=1";
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .header("User-Agent", USER_AGENT)
                .GET()
                .build();
        HttpResponse<String> resp = CLIENT.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() != 200) return Optional.empty();
        JsonNode arr = MAPPER.readTree(resp.body());
        if (!arr.isArray() || arr.size() == 0) return Optional.empty();
        JsonNode first = arr.get(0);
        double lat = first.path("lat").asDouble(Double.NaN);
        double lon = first.path("lon").asDouble(Double.NaN);
        if (Double.isNaN(lat) || Double.isNaN(lon)) return Optional.empty();
        return Optional.of(new Point2D(lat, lon));
    }
}
