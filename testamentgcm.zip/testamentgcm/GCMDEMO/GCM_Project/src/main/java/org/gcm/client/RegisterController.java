package org.gcm.client;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.gcm.common.Message;
import org.gcm.common.enums.MessageType;

import java.io.IOException;

public class RegisterController {

    @FXML private TextField tfUser;
    @FXML private PasswordField pfPass;
    @FXML private TextField tfEmail;
    @FXML private Label lblStatus;
    @FXML private TextField firstNameField;
    @FXML private TextField lastNameField;
    @FXML private TextField phoneField;
    @FXML
    public void handleRegisterSubmit() {

        String user = tfUser.getText();
        String pass = pfPass.getText();
        String email = tfEmail.getText();
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String phone = phoneField.getText();

        if (user.isEmpty() || pass.isEmpty() || email.isEmpty() || firstName.isEmpty() || lastName.isEmpty()) {
            lblStatus.setText("Please fill in all required fields (Name, User, Pass, Email).");
            return;
        }

        new Thread(() -> {
            try {
                GcmClient client = GcmClient.getInstance();

                String[] regData = {
                        user,
                        pass,
                        email,
                        "customer",
                        firstName,
                        lastName,
                        phone
                };

                client.sendRequest(new Message(MessageType.REGISTER_REQUEST, regData));

                Object response = client.waitForResponse();

                boolean success = (Boolean) response;

                Platform.runLater(() -> {
                    if (success) {
                        showAlert("Success", "Account created successfully! Please login.");
                        handleBack();
                    } else {
                        lblStatus.setText("Username/Email exists or server error.");
                    }
                });

            } catch (Exception e) {
                e.printStackTrace();
                Platform.runLater(() -> lblStatus.setText("Connection Error: " + e.getMessage()));
            }
        }).start();
    }

    @FXML
    public void handleBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/gcm/client/LoginView.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) tfUser.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
