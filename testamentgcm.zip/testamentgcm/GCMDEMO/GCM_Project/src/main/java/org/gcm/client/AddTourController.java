package org.gcm.client;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.gcm.common.Message;
import org.gcm.common.dto.PoiDto;
import org.gcm.common.dto.TourDto;
import org.gcm.common.enums.MessageType;
import org.gcm.client.ClientSession;
import org.gcm.client.GcmClient;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class AddTourController {

    @FXML private TextField tfCityId, tfName, tfPrice;
    @FXML private TextArea taDesc;
    @FXML private Label lblStatus;

    @FXML private ListView<PoiDto> lvPois;

    @FXML
    public void initialize() {

        lvPois.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        tfCityId.focusedProperty().addListener((obs, oldVal, newVal) -> {
            if (!newVal) {
                loadPoisForCity();
            }
        });
    }

    private void loadPoisForCity() {
        try {
            Long cityId = Long.parseLong(tfCityId.getText());

            GcmClient.getInstance().sendRequest(new Message(MessageType.GET_CITY_POIS, cityId));

            System.out.println("Requesting POIs for city: " + cityId);

        } catch (NumberFormatException e) {

        }
    }

    public void setPoisList(List<PoiDto> pois) {
        ObservableList<PoiDto> observablePois = FXCollections.observableArrayList(pois);
        lvPois.setItems(observablePois);
    }

    @FXML
    public void handleSubmit() {
        try {

            Long cityId = Long.parseLong(tfCityId.getText());
            String name = tfName.getText();
            String desc = taDesc.getText();

            double price = tfPrice.getText().isEmpty() ? 0.0 : Double.parseDouble(tfPrice.getText());

            ObservableList<PoiDto> selectedItems = lvPois.getSelectionModel().getSelectedItems();

            List<Long> poiIds = new ArrayList<>();
            for (PoiDto p : selectedItems) {
                poiIds.add(p.getId());
            }

            System.out.println("Selected POI IDs: " + poiIds);

            TourDto tourDto = new TourDto(0L, cityId, name, desc, price, "2h");
            tourDto.setPoiIds(poiIds);

            Message msg = new Message(MessageType.ADD_TOUR_REQUEST, tourDto);

            new Thread(() -> {
                try {
                    GcmClient.getInstance().sendRequest(msg);
                    javafx.application.Platform.runLater(() -> lblStatus.setText("Tour Created!"));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }).start();

        } catch (NumberFormatException e) {
            lblStatus.setText("Invalid City ID or Price");
        }
    }
}
