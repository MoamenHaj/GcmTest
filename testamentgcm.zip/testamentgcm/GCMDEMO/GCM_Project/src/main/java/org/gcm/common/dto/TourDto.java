package org.gcm.common.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class TourDto implements Serializable {
    private Long tourId;
    private Long cityId;
    private String tourName;
    private String description;
    private double price;
    private String duration;
    private List<String> poiNames = new ArrayList<>();
    private List<Long> poiIds = new ArrayList<>();

    private boolean isPurchased = false;

    public TourDto(Long tourId, Long cityId, String tourName, String description, double price, String duration) {
        this.tourId = tourId;
        this.cityId = cityId;
        this.tourName = tourName;
        this.description = description;
        this.price = price;
        this.duration = duration;
    }

    public Long getTourId() { return tourId; }
    public Long getCityId() { return cityId; }
    public String getTourName() { return tourName; }
    public String getDescription() { return description; }
    public double getPrice() { return price; }
    public String getDuration() { return duration; }

    public List<String> getPoiNames() { return poiNames; }
    public void setPoiNames(List<String> poiNames) { this.poiNames = poiNames; }

    public List<Long> getPoiIds() { return poiIds; }
    public void setPoiIds(List<Long> poiIds) { this.poiIds = poiIds; }

    public boolean isPurchased() { return isPurchased; }
    public void setPurchased(boolean purchased) { isPurchased = purchased; }

    @Override
    public String toString() { return tourName; }
}
