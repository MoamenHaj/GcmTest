package org.gcm.client;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.gcm.common.Message;
import org.gcm.common.dto.CityDto;
import org.gcm.common.dto.UserDto;
import org.gcm.common.enums.MessageType;

import java.io.IOException;

public class AddCityController {
    @FXML private TextField tfName;
    @FXML private TextArea taDesc;
    @FXML private Label lblStatus;
    @FXML private Label lblTitle;
    @FXML private Button btnSubmit;

    private Long cityIdToEdit = null;

    public void setCityData(CityDto city) {
        if (city != null) {
            this.cityIdToEdit = city.getCityId();
            tfName.setText(city.getCityName());
            taDesc.setText(city.getDescription());

            if (lblTitle != null) lblTitle.setText("Edit City");
            if (btnSubmit != null) btnSubmit.setText("Save Changes");
        }
    }

    @FXML
    public void handleSubmit() {
        String name = tfName.getText();
        String desc = taDesc.getText();

        if(name.isEmpty() || desc.isEmpty()) {
            lblStatus.setText("All fields are required.");
            return;
        }

        UserDto user = ClientSession.getInstance().getUser();

        String payload = name + "::" + desc;

        String action = (cityIdToEdit == null) ? "CREATE" : "UPDATE_INFO";
        Long relatedId = (cityIdToEdit == null) ? null : cityIdToEdit;

        Object[] reqData = { user.getId(), "CITY", relatedId, action, payload };

        new Thread(() -> {
            GcmClient.getInstance().sendRequest(new Message(MessageType.WORKER_UPDATE_REQUEST, reqData));
            Object response = GcmClient.getInstance().waitForResponse();

            javafx.application.Platform.runLater(() -> {
                if (response instanceof Message && ((Message)response).getData() instanceof Boolean && (Boolean)((Message)response).getData()) {
                    lblStatus.setText("Request sent to Manager!");
                    if (cityIdToEdit == null) {
                        tfName.clear(); taDesc.clear();
                    }
                } else {
                    lblStatus.setText("Failed to send request.");
                }
            });
        }).start();
    }

    @FXML
    public void handleBack() {
        try {
            Stage stage = (Stage) tfName.getScene().getWindow();

            stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/org/gcm/client/ContentDashboard.fxml"))));
        } catch (IOException e) { e.printStackTrace(); }
    }
}
