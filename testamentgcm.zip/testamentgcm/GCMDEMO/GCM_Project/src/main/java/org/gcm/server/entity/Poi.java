package org.gcm.server.entity;

import jakarta.persistence.*;
import java.io.Serializable;

import org.gcm.server.entity.MapEntity;
import org.gcm.server.entity.PoiCategory;

@Entity
@Table(name = "poi")
public class Poi implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "poi_id")
    private Long poiId;

    @Column(name = "poi_name")
    private String poiName;

    @Column(name = "description")
    private String description;

    @Column(name = "lat")
    private double lat;

    @Column(name = "lng")
    private double lng;

    @Column(name = "city_id")
    private Long cityId;

    @ManyToOne
    @JoinColumn(name = "map_id")
    private MapEntity map;

    @ManyToOne
    @JoinColumn(name = "category_id")
    private PoiCategory category;

    public Poi() {}

    public Long getPoiId() { return poiId; }
    public void setPoiId(Long poiId) { this.poiId = poiId; }

    public String getPoiName() { return poiName; }
    public void setPoiName(String poiName) { this.poiName = poiName; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public double getLat() { return lat; }
    public void setLat(double lat) { this.lat = lat; }

    public double getLng() { return lng; }
    public void setLng(double lng) { this.lng = lng; }

    public Long getCityId() { return cityId; }
    public void setCityId(Long cityId) { this.cityId = cityId; }

    public MapEntity getMap() { return map; }
    public void setMap(MapEntity map) { this.map = map; }

    public PoiCategory getCategory() { return category; }
    public void setCategory(PoiCategory category) { this.category = category; }
}
