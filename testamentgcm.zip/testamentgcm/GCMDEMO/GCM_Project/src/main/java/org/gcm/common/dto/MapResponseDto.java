package org.gcm.common.dto;

import java.io.Serializable;
import java.util.List;

public class MapResponseDto implements Serializable {
    private MapDto map;
    private List<PoiDto> pois;

    public MapResponseDto(MapDto map, List<PoiDto> pois) {
        this.map = map;
        this.pois = pois;
    }

    public MapDto getMap() { return map; }
    public List<PoiDto> getPois() { return pois; }
}
