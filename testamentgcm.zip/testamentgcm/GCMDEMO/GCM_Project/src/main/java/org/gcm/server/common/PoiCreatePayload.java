package org.gcm.server.common;

public class PoiCreatePayload {
    private Long cityId;
    private Long categoryId;
    private String poiName;
    private String poiDesc;
    private String poiType;
    private double lat;
    private double lng;
    private Long mapId;

    public PoiCreatePayload() {}

    public PoiCreatePayload(Long cityId, Long categoryId, String poiName, String poiDesc, String poiType, double lat, double lng, Long mapId) {
        this.cityId = cityId;
        this.categoryId = categoryId;
        this.poiName = poiName;
        this.poiDesc = poiDesc;
        this.poiType = poiType;
        this.lat = lat;
        this.lng = lng;
        this.mapId = mapId;
    }

    public Long getCityId() { return cityId; }
    public void setCityId(Long cityId) { this.cityId = cityId; }

    public Long getCategoryId() { return categoryId; }
    public void setCategoryId(Long categoryId) { this.categoryId = categoryId; }

    public String getPoiName() { return poiName; }
    public void setPoiName(String poiName) { this.poiName = poiName; }

    public String getPoiDesc() { return poiDesc; }
    public void setPoiDesc(String poiDesc) { this.poiDesc = poiDesc; }

    public String getPoiType() { return poiType; }
    public void setPoiType(String poiType) { this.poiType = poiType; }

    public double getLat() { return lat; }
    public void setLat(double lat) { this.lat = lat; }

    public double getLng() { return lng; }
    public void setLng(double lng) { this.lng = lng; }

    public Long getMapId() { return mapId; }
    public void setMapId(Long mapId) { this.mapId = mapId; }
}
