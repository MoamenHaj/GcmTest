package org.gcm.client;

import org.gcm.common.Message;
import org.gcm.common.dto.PoiDto;
import org.gcm.common.enums.MessageType;
import org.gcm.ocsf.AbstractClient;
import java.io.IOException;
import java.util.List;

public class GcmClient extends AbstractClient {

    private static GcmClient instance;
    public static org.gcm.client.EditTourController editTourController;

    private Object lastResponse;
    private boolean isWaitingForResponse = false;

    private GcmClient(String host, int port) throws IOException {
        super(host, port);
        openConnection();
        System.out.println("✅ Client connected to server on " + host + ":" + port);
    }

    public static void initialize(String host, int port) throws IOException {
        if (instance == null) {
            instance = new GcmClient(host, port);
        }
    }

    public static GcmClient getInstance() {
        return instance;
    }

    @Override
    protected void handleMessageFromServer(Object msg) {
        if (msg instanceof Message) {
            Message message = (Message) msg;
            System.out.println("📩 Response received: " + message.getType());

            switch (message.getType()) {
                case GET_CITY_POIS_RESPONSE:

                    if (editTourController != null) {
                        List<PoiDto> pois = (List<PoiDto>) message.getData();

                        javafx.application.Platform.runLater(() -> {
                            editTourController.setPoisList(pois);
                        });
                    }
                    break;

            }

            lastResponse = message.getData();
            isWaitingForResponse = false;

        } else {
            System.out.println("Unknown message type received: " + msg.getClass());
        }
    }

    public void sendRequest(Message message) {
        try {
            isWaitingForResponse = true;
            sendToServer(message);
        } catch (IOException e) {
            System.err.println("❌ Failed to send message to server.");
            e.printStackTrace();
        }
    }

    public Object waitForResponse() {
        while (isWaitingForResponse) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        return lastResponse;
    }
}
