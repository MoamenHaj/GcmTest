package org.gcm.client;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.gcm.common.Message;
import org.gcm.common.dto.CityDto;
import org.gcm.common.dto.PoiDto;
import org.gcm.common.dto.TourDto;
import org.gcm.common.enums.MessageType;
import java.util.ArrayList;
import java.util.List;

public class EditTourController {

    @FXML private TextField tfName, tfPrice, tfDuration;
    @FXML private TextArea taDescription;

    @FXML private ComboBox<PoiDto> cmbPois;
    @FXML private ListView<PoiDto> lvRoute;

    private ObservableList<PoiDto> routeList = FXCollections.observableArrayList();

    private TourDto currentTour;
    private Long currentCityId;

    @FXML
    public void initialize() {

        lvRoute.setItems(routeList);

        lvRoute.setCellFactory(param -> new ListCell<PoiDto>() {
            @Override
            protected void updateItem(PoiDto item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText((getIndex() + 1) + ". " + item.getName());
                    setStyle("-fx-font-weight: bold; -fx-padding: 5;");
                }
            }
        });

    }

    public void setTourData(CityDto city, TourDto tour) {
        this.currentCityId = city.getCityId();
        this.currentTour = tour;

        Message msg = new Message(MessageType.GET_CITY_POIS, currentCityId);
        GcmClient.getInstance().sendRequest(msg);

        if (tour != null) {
            tfName.setText(tour.getTourName());
            taDescription.setText(tour.getDescription());
            tfPrice.setText(String.valueOf(tour.getPrice()));

        }
    }

    public void setPoisList(List<PoiDto> pois) {

        cmbPois.setItems(FXCollections.observableArrayList(pois));
    }

    @FXML
    public void handleAddPoi() {
        PoiDto selected = cmbPois.getValue();
        if (selected == null) return;

        if (routeList.contains(selected)) {
            showAlert("Duplicate", "This POI is already in the route.");
            return;
        }
        routeList.add(selected);
        cmbPois.getSelectionModel().clearSelection();
    }

    @FXML
    public void handleRemovePoi() {
        PoiDto selected = lvRoute.getSelectionModel().getSelectedItem();
        if (selected != null) routeList.remove(selected);
    }

    @FXML
    public void handleMoveUp() {
        int index = lvRoute.getSelectionModel().getSelectedIndex();
        if (index > 0) {
            PoiDto item = routeList.remove(index);
            routeList.add(index - 1, item);
            lvRoute.getSelectionModel().select(index - 1);
        }
    }

    @FXML
    public void handleMoveDown() {
        int index = lvRoute.getSelectionModel().getSelectedIndex();
        if (index >= 0 && index < routeList.size() - 1) {
            PoiDto item = routeList.remove(index);
            routeList.add(index + 1, item);
            lvRoute.getSelectionModel().select(index + 1);
        }
    }

    @FXML
    public void handleSave() {
        try {
            String name = tfName.getText();
            double price = Double.parseDouble(tfPrice.getText());

            List<Long> orderedPoiIds = new ArrayList<>();
            for (PoiDto p : routeList) {
                orderedPoiIds.add(p.getId());
            }

            TourDto tourToSend = new TourDto(
                    (currentTour != null ? currentTour.getCityId() : 0L),
                    currentCityId,
                    name,
                    taDescription.getText(),
                    price,
                    tfDuration.getText()
            );
            tourToSend.setPoiIds(orderedPoiIds);

            MessageType type = (currentTour == null) ? MessageType.ADD_TOUR_REQUEST : MessageType.UPDATE_TOUR_REQUEST;
            GcmClient.getInstance().sendRequest(new Message(type, tourToSend));

            handleCancel();

        } catch (NumberFormatException e) {
            showAlert("Invalid Input", "Price must be a number.");
        }
    }

    @FXML
    public void handleCancel() {
        Stage stage = (Stage) tfName.getScene().getWindow();
        stage.close();
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
