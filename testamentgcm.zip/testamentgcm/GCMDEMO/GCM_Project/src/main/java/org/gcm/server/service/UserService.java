package org.gcm.server.service;

import org.gcm.common.dto.UserDto;
import org.gcm.server.db.GcmRepository;
import org.gcm.server.entity.AppUser;
import org.gcm.server.entity.CustomerProfile;

public class UserService {
    private static UserService instance;
    private GcmRepository repository;

    private UserService() {
        this.repository = GcmRepository.getInstance();
    }

    public static UserService getInstance() {
        if (instance == null) instance = new UserService();
        return instance;
    }

    public UserDto login(String username, String password) {
        AppUser user = repository.findUserByUsername(username);

        if (user != null && user.getPassword().equals(password)) {
            return new UserDto(user.getUserId(), user.getUsername(), user.getEmail(), user.getRole());
        }
        return null;
    }

    public boolean register(String username, String password, String email, String first, String last, String phone) {
        if (repository.findUserByUsername(username) != null) return false;

        AppUser user = new AppUser(username, password, email, "CUSTOMER", phone);
        if (repository.save(user)) {
            CustomerProfile profile = new CustomerProfile(user.getUserId(), first, last);
            repository.save(profile);
            return true;
        }
        return false;
    }
}
