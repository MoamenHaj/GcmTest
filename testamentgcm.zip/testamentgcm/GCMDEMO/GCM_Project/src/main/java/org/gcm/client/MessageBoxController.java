package org.gcm.client;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class MessageBoxController {

    @FXML private Label lblTitle;
    @FXML private Label lblContent;
    @FXML private Button btnClose;

    public void setDate(String title, String content) {
        lblTitle.setText(title);
        lblContent.setText(content);
    }

    @FXML
    public void handleClose() {

        Stage stage = (Stage) btnClose.getScene().getWindow();
        stage.close();
    }
}
