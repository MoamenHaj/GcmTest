package org.gcm.client;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.gcm.common.dto.TourDto;
import java.util.HashSet;
import java.util.Set;

public class ClientData {

    private static ClientData instance;

    private ObservableList<TourDto> allTours = FXCollections.observableArrayList();
    private Set<Long> ownedTourIds = new HashSet<>();

    public static ClientData getInstance() {
        if (instance == null) instance = new ClientData();
        return instance;
    }

    public ObservableList<TourDto> getAllTours() { return allTours; }
    public Set<Long> getOwnedTourIds() { return ownedTourIds; }
}
