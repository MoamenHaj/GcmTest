package org.gcm.server.entity;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "tour")
public class Tour {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tour_id")
    private Long tourId;

    @Column(name = "city_id")
    private Long cityId;

    @Column(name = "tour_name")
    private String tourName;

    @Column(name = "general_desc")
    private String description;

    @Column(name = "price")
    private double price;

    @Column(name = "is_active")
    private boolean isActive = true;

    @OneToMany(mappedBy = "tour", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @OrderBy("stopOrder ASC")
    private List<TourStop> stops = new ArrayList<>();

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "map_id", referencedColumnName = "id")
    private MapEntity map;

    public Tour() {}

    public Tour(Long cityId, String tourName, String description, double price) {
        this.cityId = cityId;
        this.tourName = tourName;
        this.description = description;
        this.price = price;
        this.isActive = true;
    }

    public Long getTourId() { return tourId; }
    public void setTourId(Long tourId) { this.tourId = tourId; }

    public Long getCityId() { return cityId; }
    public void setCityId(Long cityId) { this.cityId = cityId; }

    public String getTourName() { return tourName; }
    public void setTourName(String tourName) { this.tourName = tourName; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    public List<TourStop> getStops() {
        return stops;
    }

    public void setStops(List<TourStop> stops) {
        this.stops = stops;
    }

    public void addStop(Poi poi, int minutes) {

        int nextOrder = this.stops.size() + 1;

        TourStop newStop = new TourStop(this, poi, nextOrder, minutes);
        this.stops.add(newStop);
    }

    public MapEntity getMap() { return map; }
    public void setMap(MapEntity map) { this.map = map; }
}
