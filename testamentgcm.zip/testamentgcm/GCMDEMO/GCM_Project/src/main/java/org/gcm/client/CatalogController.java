package org.gcm.client;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.gcm.common.Message;
import org.gcm.common.dto.CityDto;
import org.gcm.common.dto.UserDto;
import org.gcm.common.enums.MessageType;
import java.io.IOException;
import java.util.List;

public class CatalogController {

    @FXML private TilePane gridCities;
    @FXML private Label lblWelcome;
    @FXML private Label lblRole;
    @FXML private Button btnContentDashboard;
    @FXML private Button btnMessageBox;

    @FXML
    public void initialize() {

        UserDto currentUser = ClientSession.getInstance().getUser();
        if (currentUser != null) {
            lblWelcome.setText(currentUser.getUsername());

            String role = currentUser.getRole();
            if (lblRole != null) lblRole.setText(role);

            boolean isWorker = "CONTENT_MANAGER".equalsIgnoreCase(role) || "CONTENT_WORKER".equalsIgnoreCase(role);
            boolean isManager = "ADMIN".equalsIgnoreCase(role) || "Manager".equalsIgnoreCase(role);

            if (btnContentDashboard != null) {

                boolean canManageContent = isManager || isWorker;
                btnContentDashboard.setVisible(canManageContent);
                btnContentDashboard.setManaged(canManageContent);
            }

            if (btnMessageBox != null) {

                btnMessageBox.setVisible(isManager);
                btnMessageBox.setManaged(isManager);
            }
        }

        loadRealCatalogData();
    }

    private void loadRealCatalogData() {
        new Thread(() -> {
            try {

                GcmClient.getInstance().sendRequest(new Message(MessageType.GET_CATALOG_REQUEST, null));
                Object response = GcmClient.getInstance().waitForResponse();

                if (response instanceof Message) {
                    Message msg = (Message) response;
                    if (msg.getType() == MessageType.GET_CATALOG_RESPONSE) {
                        List<CityDto> cities = (List<CityDto>) msg.getData();
                        Platform.runLater(() -> displayCities(cities));
                    }
                }

                else if (response instanceof List) {
                    List<CityDto> cities = (List<CityDto>) response;
                    Platform.runLater(() -> displayCities(cities));
                }
            } catch (Exception e) { e.printStackTrace(); }
        }).start();
    }

    private void displayCities(List<CityDto> cities) {
        gridCities.getChildren().clear();
        for (CityDto city : cities) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/gcm/client/CityCard.fxml"));
                VBox card = loader.load();

                ((Label) card.lookup("#lblCityName")).setText(city.getCityName());
                ((Label) card.lookup("#lblCityDesc")).setText(city.getDescription());
                ((Button) card.lookup("#btnViewTours")).setOnAction(e -> handleViewCity(city));

                gridCities.getChildren().add(card);
            } catch (IOException e) { e.printStackTrace(); }
        }
    }

    private void handleViewCity(CityDto city) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/gcm/client/CityToursView.fxml"));
            javafx.scene.Parent root = loader.load();

            CityToursController controller = loader.getController();
            controller.setCityData(city);

            Stage stage = (Stage) gridCities.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) { e.printStackTrace(); }
    }

    @FXML public void handleLogout() {
        try {
            ClientSession.getInstance().logout();
            Stage stage = (Stage) gridCities.getScene().getWindow();
            stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/org/gcm/client/LoginView.fxml"))));
        } catch (IOException e) { e.printStackTrace(); }
    }

    @FXML public void openContentDashboard() {
        try {
            Stage stage = (Stage) gridCities.getScene().getWindow();
            stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/org/gcm/client/ContentDashboard.fxml"))));
        } catch (IOException e) { e.printStackTrace(); }
    }

    @FXML public void openMessageBox() {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/gcm/client/ManagerRequestsView.fxml"));
            javafx.scene.Parent root = loader.load();

            Stage stage = (Stage) gridCities.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Manager Requests");

        } catch (IOException e) { e.printStackTrace(); }
    }
}
