package org.gcm.server.entity;

import jakarta.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "city_map")
public class CityMap {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "map_id")
    private Long mapId;

    @Column(name = "city_id")
    private Long cityId;

    @Column(name = "is_active")
    private boolean isActive;

    @Column(name = "created_at")
    private Timestamp createdAt;

    @Column(name = "map_title")
    private String mapTitle = "General Map";

    @Column(name = "short_desc")
    private String shortDesc = "Map Description";

    public CityMap() {}

    public Long getMapId() { return mapId; }
    public void setMapId(Long mapId) { this.mapId = mapId; }

    public Long getCityId() { return cityId; }
    public void setCityId(Long cityId) { this.cityId = cityId; }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public String getMapTitle() { return mapTitle; }
    public void setMapTitle(String mapTitle) { this.mapTitle = mapTitle; }

    public String getShortDesc() { return shortDesc; }
    public void setShortDesc(String shortDesc) { this.shortDesc = shortDesc; }
}
