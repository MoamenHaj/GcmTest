package org.gcm.server.entity;

import jakarta.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "modification_request")
public class ModificationRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "request_id")
    private Long requestId;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "related_entity")
    private String relatedEntity;

    @Column(name = "related_id")
    private Long relatedId;

    @Column(name = "change_type")
    private String changeType;

    @Column(name = "new_data_json")
    private String newDataJson;

    @Column(name = "status")
    private String status;

    @Column(name = "request_date")
    private Timestamp requestDate;

    public ModificationRequest() {}

    public ModificationRequest(Long userId, String relatedEntity, Long relatedId, String changeType, String newDataJson, String status) {
        this.userId = userId;
        this.relatedEntity = relatedEntity;
        this.relatedId = relatedId;
        this.changeType = changeType;
        this.newDataJson = newDataJson;
        this.status = status;
        this.requestDate = new Timestamp(System.currentTimeMillis());
    }

    public Long getRequestId() { return requestId; }
    public void setRequestId(Long requestId) { this.requestId = requestId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getRelatedEntity() { return relatedEntity; }
    public void setRelatedEntity(String relatedEntity) { this.relatedEntity = relatedEntity; }

    public Long getRelatedId() { return relatedId; }
    public void setRelatedId(Long relatedId) { this.relatedId = relatedId; }

    public String getChangeType() { return changeType; }
    public void setChangeType(String changeType) { this.changeType = changeType; }

    public String getNewDataJson() { return newDataJson; }
    public void setNewDataJson(String newDataJson) { this.newDataJson = newDataJson; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Timestamp getRequestDate() { return requestDate; }
    public void setRequestDate(Timestamp requestDate) { this.requestDate = requestDate; }
}
