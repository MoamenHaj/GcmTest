package org.gcm.client;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.gcm.common.Message;
import org.gcm.common.dto.UserDto;
import org.gcm.common.enums.MessageType;

import java.io.IOException;

public class LoginController {

    @FXML private TextField tfUsername;
    @FXML private PasswordField pfPassword;
    @FXML private Label lblStatus;

    @FXML
    public void handleLogin() {
        String user = tfUsername.getText();
        String pass = pfPassword.getText();

        if (user.isEmpty() || pass.isEmpty()) {
            lblStatus.setText("Please enter username and password.");
            return;
        }

        new Thread(() -> {
            try {
                GcmClient client = GcmClient.getInstance();

                String[] loginData = {user, pass};
                client.sendRequest(new Message(MessageType.LOGIN_REQUEST, loginData));

                Object response = client.waitForResponse();

                Platform.runLater(() -> {

                    if (response != null) {
                        System.out.println("DEBUG Check: " + response.getClass().getName());
                    }

                    if (response instanceof UserDto) {
                        UserDto loggedUser = (UserDto) response;
                        ClientSession.getInstance().setUser(loggedUser);
                        System.out.println("Login Successful: " + loggedUser.getUsername());

                        loadMainView();

                    } else if (response instanceof Message) {

                        Message msg = (Message) response;
                        if (msg.getData() instanceof UserDto) {
                            UserDto loggedUser = (UserDto) msg.getData();
                            System.out.println("Login Successful (via Message): " + loggedUser.getUsername());
                            loadMainView();
                        } else {
                            lblStatus.setText("Login failed (Invalid Data).");
                        }
                    } else {

                        lblStatus.setText("Invalid username or password.");
                    }
                });

            } catch (Exception e) {
                e.printStackTrace();
                Platform.runLater(() -> lblStatus.setText("Connection Error."));
            }
        }).start();
    }

    @FXML
    public void handleRegister() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/gcm/client/RegisterView.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) tfUsername.getScene().getWindow();
            stage.setScene(new Scene(root));

        } catch (IOException e) {
            e.printStackTrace();
            lblStatus.setText("Error opening registration screen.");
        }
    }

    private void loadMainView() {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/gcm/client/CatalogView.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) tfUsername.getScene().getWindow();

            stage.setTitle("GCM Catalog - Main Menu");
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
            lblStatus.setText("Error loading main view.");
        }
    }
}
