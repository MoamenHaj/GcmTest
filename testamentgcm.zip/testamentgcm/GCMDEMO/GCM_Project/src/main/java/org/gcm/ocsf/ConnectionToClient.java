package org.gcm.ocsf;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.util.HashMap;

public class ConnectionToClient extends Thread
{

    private AbstractServer server;

    private Socket clientSocket;

    private ObjectInputStream input;

    private ObjectOutputStream output;

    private boolean readyToStop;

    private HashMap savedInfo = new HashMap(10);

    ConnectionToClient(ThreadGroup group, Socket clientSocket,
                       AbstractServer server) throws IOException
    {
        super(group,(Runnable)null);

        this.clientSocket = clientSocket;
        this.server = server;

        clientSocket.setSoTimeout(0);

        try
        {
            input = new ObjectInputStream(clientSocket.getInputStream());
            output = new ObjectOutputStream(clientSocket.getOutputStream());
        }
        catch (IOException ex)
        {
            try
            {
                closeAll();
            }
            catch (Exception exc) { }

            throw ex;
        }

        readyToStop = false;
        start();
    }

    final public void sendToClient(Object msg) throws IOException
    {
        if (clientSocket == null || output == null)
            throw new SocketException("socket does not exist");

        output.writeObject(msg);
    }

    final public void close() throws IOException
    {
        readyToStop = true;

        try
        {
            closeAll();
        }
        finally
        {
            server.clientDisconnected(this);
        }
    }

    final public InetAddress getInetAddress()
    {
        return clientSocket == null ? null : clientSocket.getInetAddress();
    }

    public String toString()
    {
        return clientSocket == null ? null :
                clientSocket.getInetAddress().getHostName()
                        +" (" + clientSocket.getInetAddress().getHostAddress() + ")";
    }

    public void setInfo(String infoType, Object info)
    {
        savedInfo.put(infoType, info);
    }

    public Object getInfo(String infoType)
    {
        return savedInfo.get(infoType);
    }

    final public void run()
    {
        server.clientConnected(this);

        try
        {

            Object msg;

            while (!readyToStop)
            {

                msg = input.readObject();
                server.receiveMessageFromClient(msg, this);
            }
        }
        catch (Exception exception)
        {
            if (!readyToStop)
            {
                try
                {
                    closeAll();
                }
                catch (Exception ex) { }

                server.clientException(this, exception);
            }
        }
    }

    private void closeAll() throws IOException
    {
        try
        {

            if (clientSocket != null)
                clientSocket.close();

            if (output != null)
                output.close();

            if (input != null)
                input.close();
        }
        finally
        {

            output = null;
            input = null;
            clientSocket = null;
        }
    }

    protected void finalize()
    {
        try
        {
            closeAll();
        }
        catch(IOException e) {}
    }
}
