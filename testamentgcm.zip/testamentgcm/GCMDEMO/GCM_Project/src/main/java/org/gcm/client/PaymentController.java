package org.gcm.client;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.gcm.common.Message;
import org.gcm.common.dto.TourDto;
import org.gcm.common.dto.UserDto;
import org.gcm.common.enums.MessageType;

public class PaymentController {

    @FXML private Label lblTourInfo;
    @FXML private TextField tfCardNumber;
    @FXML private TextField tfExpiry;
    @FXML private TextField tfCvv;
    @FXML private Label lblError;

    private TourDto tour;
    private Runnable onSuccessCallback;

    public void setPaymentData(TourDto tour, Runnable onSuccess) {
        this.tour = tour;
        this.onSuccessCallback = onSuccess;
        lblTourInfo.setText("Purchasing: " + tour.getTourName() + " ($" + tour.getPrice() + ")");
    }

    @FXML
    public void handlePay() {
        String card = tfCardNumber.getText();
        String expiry = tfExpiry.getText();
        String cvv = tfCvv.getText();

        if (card.isEmpty() || expiry.isEmpty() || cvv.isEmpty()) {
            showError("All fields are required.");
            return;
        }

        if (card.length() < 13) {
            showError("Invalid Card Number.");
            return;
        }

        lblError.setText("Processing Payment...");
        lblError.setStyle("-fx-text-fill: blue;");
        lblError.setVisible(true);

        new Thread(() -> {
            try {
                System.out.println("DEBUG: Sending PURCHASE_TOUR_REQUEST...");

                UserDto user = ClientSession.getInstance().getUser();
                Object[] reqData = { user.getId(), tour.getTourId() };

                GcmClient.getInstance().sendRequest(new Message(MessageType.PURCHASE_TOUR_REQUEST, reqData));

                System.out.println("DEBUG: Waiting for response...");
                Object response = GcmClient.getInstance().waitForResponse();
                System.out.println("DEBUG: Response received: " + response);

                boolean success = false;

                if (response instanceof Message && ((Message)response).getType() == MessageType.PURCHASE_TOUR_RESPONSE) {
                    success = (boolean) ((Message)response).getData();
                }

                else if (response instanceof Boolean) {
                    success = (Boolean) response;
                } else {
                    System.err.println("DEBUG: Unexpected response type: " + response.getClass().getName());
                }

                System.out.println("DEBUG: Purchase success: " + success);

                final boolean finalSuccess = success;
                Platform.runLater(() -> {
                    if (finalSuccess) {
                        showSuccessAlert();
                        if (onSuccessCallback != null) onSuccessCallback.run();
                        closeWindow();
                    } else {
                        showError("Payment Failed. Try again.");
                    }
                });

            } catch (Exception e) {
                e.printStackTrace();
                Platform.runLater(() -> showError("Connection Error: " + e.getMessage()));
            }
        }).start();
    }

    private void showSuccessAlert() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Payment Successful");
        alert.setHeaderText(null);
        alert.setContentText("Thank you! You can now view the tour details.");
        alert.showAndWait();
    }

    private void showError(String msg) {
        lblError.setText(msg);
        lblError.setStyle("-fx-text-fill: red;");
        lblError.setVisible(true);
    }

    @FXML
    public void handleCancel() {
        closeWindow();
    }

    private void closeWindow() {
        Stage stage = (Stage) lblTourInfo.getScene().getWindow();
        stage.close();
    }
}
