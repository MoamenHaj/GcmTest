package org.gcm.client;

import org.gcm.common.dto.UserDto;

public class ClientSession {
    private static ClientSession instance;
    private UserDto user;

    private ClientSession() {}

    public static ClientSession getInstance() {
        if (instance == null) {
            instance = new ClientSession();
        }
        return instance;
    }

    public void setUser(UserDto user) {
        this.user = user;
    }

    public UserDto getUser() {
        return user;
    }

    public void logout() {
        this.user = null;
    }
}
