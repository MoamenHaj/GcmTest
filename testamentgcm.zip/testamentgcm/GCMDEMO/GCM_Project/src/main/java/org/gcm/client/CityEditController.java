package org.gcm.client;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.gcm.common.Message;
import org.gcm.common.dto.CityDto;
import org.gcm.common.dto.TourDto;
import org.gcm.common.dto.UserDto;
import org.gcm.common.enums.MessageType;
import java.io.IOException;
import java.util.List;

public class CityEditController {

    @FXML private Label lblCityName;
    @FXML private VBox listContainer;

    private CityDto currentCity;

    public void setCityData(CityDto city) {
        this.currentCity = city;
        if (city != null) lblCityName.setText(city.getCityName());
        loadRealTours();
    }

    private void loadRealTours() {
        new Thread(() -> {
            try {
                GcmClient.getInstance().sendRequest(new Message(MessageType.GET_CITY_TOURS, currentCity.getCityId()));
                Object response = GcmClient.getInstance().waitForResponse();

                List<TourDto> tours = null;
                if (response instanceof Message && ((Message)response).getType() == MessageType.GET_CITY_TOURS_RESPONSE) {
                    tours = (List<TourDto>) ((Message)response).getData();
                } else if (response instanceof List) {
                    tours = (List<TourDto>) response;
                }

                if (tours != null) {
                    final List<TourDto> finalTours = tours;
                    Platform.runLater(() -> displayTours(finalTours));
                }

            } catch (Exception e) { e.printStackTrace(); }
        }).start();
    }

    private void displayTours(List<TourDto> tours) {
        listContainer.getChildren().clear();
        if (tours.isEmpty()) {
            listContainer.getChildren().add(new Label("No tours found. Click '+ Add New Tour'."));
        } else {
            for (TourDto tour : tours) addTourRow(tour);
        }
    }

    private void addTourRow(TourDto tour) {
        VBox card = new VBox(5);
        card.setStyle("-fx-background-color: white; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.05), 5, 0, 0, 2); -fx-background-radius: 5; -fx-padding: 15;");

        HBox top = new HBox();
        Label lblTitle = new Label(tour.getTourName());
        lblTitle.setStyle("-fx-font-weight: bold; -fx-font-size: 16px;");
        Label lblPrice = new Label("$" + tour.getPrice());
        lblPrice.setStyle("-fx-background-color: #f5f5f5; -fx-padding: 3 8; -fx-background-radius: 10;");
        Region spacer = new Region(); HBox.setHgrow(spacer, Priority.ALWAYS);
        top.getChildren().addAll(lblTitle, spacer, lblPrice);

        Label lblDesc = new Label(tour.getDescription());
        lblDesc.setStyle("-fx-text-fill: #666;");

        HBox actions = new HBox(10);
        actions.setPadding(new Insets(10, 0, 0, 0));

        Button btnEdit = new Button("Edit");
        btnEdit.setStyle("-fx-background-color: #e3f2fd; -fx-text-fill: #2962ff; -fx-cursor: hand;");
        btnEdit.setMaxWidth(Double.MAX_VALUE); HBox.setHgrow(btnEdit, Priority.ALWAYS);

        btnEdit.setOnAction(e -> openTourEditor(tour));

        Button btnDelete = new Button("Delete");
        btnDelete.setStyle("-fx-background-color: #ffebee; -fx-text-fill: #d32f2f; -fx-cursor: hand;");
        btnDelete.setMaxWidth(Double.MAX_VALUE); HBox.setHgrow(btnDelete, Priority.ALWAYS);
        btnDelete.setOnAction(e -> deleteTour(tour));

        actions.getChildren().addAll(btnEdit, btnDelete);
        card.getChildren().addAll(top, lblDesc, actions);
        listContainer.getChildren().add(card);
    }

    @FXML public void handleAddTour() {

        openTourEditor(null);
    }

    private void deleteTour(TourDto tour) {
        new Thread(() -> {
            try {
                UserDto user = ClientSession.getInstance().getUser();

                Object[] reqData = { user.getId(), "TOUR", tour.getTourId(), "DELETE", "Request to delete tour: " + tour.getTourName() };

                GcmClient.getInstance().sendRequest(new Message(MessageType.WORKER_UPDATE_REQUEST, reqData));

                Platform.runLater(() -> {

                    System.out.println("Delete request sent for tour: " + tour.getTourName());
                });

            } catch (Exception e) { e.printStackTrace(); }
        }).start();
    }

    private void openTourEditor(TourDto tour) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/gcm/client/EditTourView.fxml"));
            javafx.scene.Parent root = loader.load();

            EditTourController controller = loader.getController();

            if (tour != null) {

                controller.setTourData(currentCity, tour);
            } else {

                controller.setTourData(currentCity, null);
            }

            Stage stage = (Stage) lblCityName.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) { e.printStackTrace(); }
    }

    @FXML public void handleBack() {
        try {
            Stage stage = (Stage) lblCityName.getScene().getWindow();
            stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/org/gcm/client/ContentDashboard.fxml"))));
        } catch (IOException e) { e.printStackTrace(); }
    }

    @FXML public void handleEditCity() {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/gcm/client/AddCityView.fxml"));
            javafx.scene.Parent root = loader.load();

            AddCityController controller = loader.getController();
            controller.setCityData(currentCity);

            Stage stage = (Stage) lblCityName.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) { e.printStackTrace(); }
    }

    @FXML public void handleDeleteCity() {
        new Thread(() -> {
            try {
                UserDto user = ClientSession.getInstance().getUser();

                Object[] reqData = { user.getId(), "CITY", currentCity.getCityId(), "DELETE", "Request to delete city: " + currentCity.getCityName() };

                GcmClient.getInstance().sendRequest(new Message(MessageType.WORKER_UPDATE_REQUEST, reqData));

                Platform.runLater(() -> {

                    handleBack();
                });

            } catch (Exception e) { e.printStackTrace(); }
        }).start();
    }

    @FXML public void handleManagePois() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/gcm/client/CityPoisView.fxml"));
            javafx.scene.Parent root = loader.load();

            CityPoisController controller = loader.getController();
            controller.setCityData(currentCity);

            Stage stage = (Stage) lblCityName.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) { e.printStackTrace(); }
    }
}
