package org.gcm.server.service;

import org.gcm.common.dto.ModificationRequestDto;
import org.gcm.server.common.JavaSerializer;
import org.gcm.server.common.TourPayload;
import org.gcm.server.db.GcmRepository;
import org.gcm.server.entity.*;
import java.util.ArrayList;
import java.util.List;

public class RequestService {
    private static RequestService instance;
    private GcmRepository repository;

    private RequestService() { repository = GcmRepository.getInstance(); }

    public static RequestService getInstance() {
        if (instance == null) instance = new RequestService();
        return instance;
    }

    public boolean createRequest(Long userId, String entity, Long relatedId, String action, String data) {
        ModificationRequest req = new ModificationRequest(userId, entity, relatedId, action, data, "PENDING");
        return repository.save(req);
    }

    public List<ModificationRequestDto> getPendingRequests() {
        List<ModificationRequest> list = repository.findPendingRequests();
        List<ModificationRequestDto> dtos = new ArrayList<>();
        for (ModificationRequest req : list) {
            dtos.add(new ModificationRequestDto(
                    req.getRequestId(),
                    "Worker " + req.getUserId(),
                    req.getRelatedEntity(),
                    req.getChangeType(),
                    "Request to " + req.getChangeType(),
                    req.getNewDataJson(),
                    req.getStatus()
            ));
        }
        return dtos;
    }

    public boolean approveRequest(Long requestId) {
        ModificationRequest req = repository.findById(ModificationRequest.class, requestId);
        if (req == null) return false;

        boolean success = false;

        if ("TOUR".equalsIgnoreCase(req.getRelatedEntity())) {
            success = handleTourRequest(req);
        } else if ("CITY".equalsIgnoreCase(req.getRelatedEntity())) {
            success = true;
        } else if ("POI".equalsIgnoreCase(req.getRelatedEntity())) {
            success = true;
        }

        if (success) {
            req.setStatus("APPROVED");
            repository.update(req);
            System.out.println("✅ Request " + requestId + " APPROVED.");
        }
        return success;
    }

    public boolean rejectRequest(Long requestId) {
        ModificationRequest req = repository.findById(ModificationRequest.class, requestId);
        if (req != null) {
            req.setStatus("REJECTED");
            repository.update(req);
            System.out.println("⛔ Request " + requestId + " REJECTED.");
            return true;
        }
        return false;
    }

    private boolean handleTourRequest(ModificationRequest req) {
        String rawData = req.getNewDataJson();
        if (rawData == null) return false;

        boolean isLegacy = rawData.contains(":");

        if (isLegacy) {

            System.out.println("⚠️ Parsing Legacy Data: " + rawData);
            try {
                String[] parts = rawData.split("::");
                if (parts.length >= 4) {
                    Tour tour = new Tour(
                            Long.parseLong(parts[0]),
                            parts[1],
                            parts[2],
                            Double.parseDouble(parts[3])
                    );

                    return repository.save(tour);
                }
            } catch (Exception ex) {
                System.err.println("❌ Failed to parse legacy data: " + ex.getMessage());
            }
        } else {

            System.out.println("📦 Parsing Java Object...");
            try {
                Object obj = JavaSerializer.fromString(rawData);

                if (obj instanceof TourPayload) {
                    TourPayload data = (TourPayload) obj;
                    Tour tour = new Tour(data.getCityId(), data.getTourName(), data.getDescription(), data.getPrice());

                    if (data.getPoiIds() != null) {
                        for (Long pid : data.getPoiIds()) {
                            Poi p = repository.findById(Poi.class, pid);
                            if (p != null) tour.addStop(p, 30);
                        }
                    }
                    return repository.save(tour);
                }
            } catch (Exception e) {
                System.err.println("❌ Failed to deserialize object: " + e.getMessage());
            }
        }

        return false;
    }
}
