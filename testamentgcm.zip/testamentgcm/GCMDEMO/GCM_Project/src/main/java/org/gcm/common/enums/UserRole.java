package org.gcm.common.enums;

public enum UserRole {
    CUSTOMER,
    CONTENT_WORKER,
    CONTENT_MANAGER,
    ADMIN
}
