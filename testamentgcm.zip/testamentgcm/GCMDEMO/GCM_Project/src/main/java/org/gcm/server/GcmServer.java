package org.gcm.server;

import org.gcm.common.Message;
import org.gcm.common.dto.CityDto;
import org.gcm.common.dto.PoiDto;
import org.gcm.common.dto.TourDto;
import org.gcm.common.enums.MessageType;
import org.gcm.ocsf.AbstractServer;
import org.gcm.ocsf.ConnectionToClient;
import org.gcm.server.service.*;

import java.io.IOException;

public class GcmServer extends AbstractServer {

    private UserService userService;
    private CatalogService catalogService;
    private RequestService requestService;
    private MapService mapService;
    private StatisticsService statisticsService;

    public GcmServer(int port) {
        super(port);

        this.userService = UserService.getInstance();
        this.catalogService = CatalogService.getInstance();
        this.requestService = RequestService.getInstance();
        this.mapService = MapService.getInstance();
        this.statisticsService = StatisticsService.getInstance();
    }

    @Override
    protected void handleMessageFromClient(Object msg, ConnectionToClient client) {
        if (!(msg instanceof Message)) return;
        Message request = (Message) msg;

        System.out.println("📩 Request: " + request.getType());

        try {
            switch (request.getType()) {

                case LOGIN_REQUEST:
                    String[] creds = (String[]) request.getData();
                    client.sendToClient(new Message(MessageType.LOGIN_RESPONSE, userService.login(creds[0], creds[1])));
                    break;

                case REGISTER_REQUEST:

                    if (request.getData() instanceof String[]) {
                        String[] regData = (String[]) request.getData();

                        boolean success = userService.register(regData[0], regData[1], regData[2], regData[3], regData[4], regData[5]);
                        client.sendToClient(new Message(MessageType.REGISTER_RESPONSE, success));
                    }
                    break;

                case GET_CATALOG_REQUEST:
                    client.sendToClient(new Message(MessageType.GET_CATALOG_RESPONSE, catalogService.getCatalog()));
                    break;

                case GET_CITY_TOURS:

                    if (request.getData() instanceof Long) {
                        client.sendToClient(new Message(MessageType.GET_CITY_TOURS_RESPONSE, catalogService.getCityTours((Long)request.getData(), null)));
                    } else if (request.getData() instanceof Object[]) {
                        Object[] params = (Object[]) request.getData();
                        client.sendToClient(new Message(MessageType.GET_CITY_TOURS_RESPONSE, catalogService.getCityTours((Long)params[0], (Long)params[1])));
                    }
                    break;

                case WORKER_UPDATE_REQUEST:
                    Object[] reqData = (Object[]) request.getData();

                    boolean reqSaved = requestService.createRequest(
                            (Long)reqData[0], (String)reqData[1], (Long)reqData[2], (String)reqData[3], (String)reqData[4]
                    );
                    client.sendToClient(new Message(MessageType.WORKER_UPDATE_RESPONSE, reqSaved));
                    break;

                case GET_PENDING_REQUESTS:
                    client.sendToClient(new Message(MessageType.GET_PENDING_REQUESTS_RESPONSE, requestService.getPendingRequests()));
                    break;

                case APPROVE_REQUEST:
                    boolean approved = requestService.approveRequest((Long) request.getData());
                    client.sendToClient(new Message(MessageType.APPROVE_REQUEST_RESPONSE, approved));
                    break;

                case ADD_CITY_REQUEST:

                    if (request.getData() instanceof String cityName) {
                        CityDto dto = new CityDto(0L, cityName, "No Description", 0, 0.0, "$");
                        catalogService.addCity(dto);
                    } else {

                        CityDto cityDto = (CityDto) request.getData();
                        catalogService.addCity(cityDto);
                    }
                    client.sendToClient(new Message(MessageType.ADD_CITY_RESPONSE, true));
                    break;

                case GET_MAP_REQUEST:

                    break;
                case GET_CITY_POIS:
                    Long cityIdForPois = (Long) request.getData();
                    client.sendToClient(new Message(MessageType.GET_CITY_POIS_RESPONSE, catalogService.getCityPois(cityIdForPois)));
                    break;
                case REJECT_REQUEST:
                    boolean rejected = requestService.rejectRequest((Long) request.getData());
                    client.sendToClient(new Message(MessageType.REJECT_REQUEST_RESPONSE, rejected));
                    break;

                case ADD_POI_REQUEST:
                    PoiDto poiDto = (PoiDto) request.getData();
                    catalogService.addPoi(poiDto);
                    client.sendToClient(new Message(MessageType.ADD_POI_RESPONSE, true));
                    break;
                case ADD_TOUR_REQUEST:
                    TourDto tourDto = (TourDto) request.getData();
                    catalogService.addTour(tourDto);
                    client.sendToClient(new Message(MessageType.ADD_TOUR_RESPONSE, true));
                    break;

                default:
                    System.out.println("⚠️ Unknown Request: " + request.getType());
            }
        } catch (Exception e) {
            e.printStackTrace();
            try { client.sendToClient(new Message(MessageType.ERROR_RESPONSE, "Server Error: " + e.getMessage())); } catch (IOException ex) {}
        }
    }

    @Override protected void serverStarted() { System.out.println("✅ Server listening on port " + getPort()); }
    @Override protected void serverStopped() { System.out.println("🛑 Server stopped."); }
    @Override protected void clientConnected(ConnectionToClient client) { System.out.println("➕ Client connected."); }
}
