package org.gcm.client;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import org.gcm.common.Message;
import org.gcm.common.dto.PurchaseReportDto;
import org.gcm.common.enums.MessageType;
import java.io.IOException;
import java.util.List;

public class ManagerStatsController {

    @FXML private Label lblTotalRevenue;
    @FXML private Label lblTotalPurchases;
    @FXML private TableView<PurchaseReportDto> tblReport;

    private TableColumn<PurchaseReportDto, Long> colId;
    private TableColumn<PurchaseReportDto, String> colDate;
    private TableColumn<PurchaseReportDto, String> colUser;
    private TableColumn<PurchaseReportDto, String> colCity;
    private TableColumn<PurchaseReportDto, String> colTour;
    private TableColumn<PurchaseReportDto, Double> colPrice;

    public void initialize() {
        setupTable();
        handleRefresh();
    }

    private void setupTable() {
        colId = new TableColumn<>("ID");
        colId.setCellValueFactory(new PropertyValueFactory<>("purchaseId"));
        colId.setPrefWidth(50);

        colDate = new TableColumn<>("Date");
        colDate.setCellValueFactory(new PropertyValueFactory<>("purchaseDate"));
        colDate.setPrefWidth(150);

        colUser = new TableColumn<>("User");
        colUser.setCellValueFactory(new PropertyValueFactory<>("userName"));
        colUser.setPrefWidth(150);

        colCity = new TableColumn<>("City");
        colCity.setCellValueFactory(new PropertyValueFactory<>("cityName"));
        colCity.setPrefWidth(150);

        colTour = new TableColumn<>("Tour");
        colTour.setCellValueFactory(new PropertyValueFactory<>("tourName"));
        colTour.setPrefWidth(200);

        colPrice = new TableColumn<>("Price");
        colPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
        colPrice.setPrefWidth(100);

        tblReport.getColumns().addAll(colId, colDate, colUser, colCity, colTour, colPrice);
    }

    @FXML
    public void handleRefresh() {
        new Thread(() -> {
            try {
                GcmClient.getInstance().sendRequest(new Message(MessageType.GET_PURCHASE_REPORT, null));
                Object response = GcmClient.getInstance().waitForResponse();

                List<PurchaseReportDto> report = null;
                if (response instanceof Message && ((Message)response).getType() == MessageType.GET_PURCHASE_REPORT_RESPONSE) {
                    report = (List<PurchaseReportDto>) ((Message)response).getData();
                } else if (response instanceof List) {
                    report = (List<PurchaseReportDto>) response;
                }

                if (report != null) {
                    final List<PurchaseReportDto> finalReport = report;
                    Platform.runLater(() -> updateUI(finalReport));
                }
            } catch (Exception e) { e.printStackTrace(); }
        }).start();
    }

    private void updateUI(List<PurchaseReportDto> report) {
        tblReport.getItems().clear();
        tblReport.getItems().addAll(report);

        double totalRevenue = report.stream().mapToDouble(PurchaseReportDto::getPrice).sum();
        int totalPurchases = report.size();

        lblTotalRevenue.setText(String.format("$%.2f", totalRevenue));
        lblTotalPurchases.setText(String.valueOf(totalPurchases));
    }

    @FXML
    public void handleBack() {
        try {
            Stage stage = (Stage) lblTotalRevenue.getScene().getWindow();
            stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/org/gcm/client/ContentDashboard.fxml"))));
        } catch (IOException e) { e.printStackTrace(); }
    }
}
