package org.gcm.client;

public class AppLauncher {
    public static void main(String[] args) {
        ClientMain.main(args);
    }
}
