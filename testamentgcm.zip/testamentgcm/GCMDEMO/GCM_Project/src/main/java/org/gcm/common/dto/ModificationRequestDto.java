package org.gcm.common.dto;

import java.io.Serial;
import java.io.Serializable;

public class ModificationRequestDto implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private Long requestId;
    private String workerName;
    private String relatedEntity;
    private String changeType;
    private String description;
    private String json;
    private String status;

    public ModificationRequestDto(Long requestId, String workerName, String relatedEntity,
                                  String changeType, String description, String json, String status) {
        this.requestId = requestId;
        this.workerName = workerName;
        this.relatedEntity = relatedEntity;
        this.changeType = changeType;
        this.description = description;
        this.json = json;
        this.status = status;
    }

    public Long getRequestId() { return requestId; }

    public String getWorkerName() { return workerName; }

    public String getDescription() { return description; }

    public String getStatus() { return status; }

    public String getRelatedEntity() { return relatedEntity; }
    public String getChangeType() { return changeType; }
    public String getJson() { return json; }
}
