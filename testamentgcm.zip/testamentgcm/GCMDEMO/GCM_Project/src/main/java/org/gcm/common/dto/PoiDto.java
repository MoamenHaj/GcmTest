package org.gcm.common.dto;

import java.io.Serializable;

public class PoiDto implements Serializable {

    private Long poiId;
    private String name;
    private String description;
    private double lat;
    private double lng;
    private int orderIndex;

    private Long cityId;

    public PoiDto(Long poiId, String name, String description, double lat, double lng, int orderIndex) {
        this.poiId = poiId;
        this.name = name;
        this.description = description;
        this.lat = lat;
        this.lng = lng;
        this.orderIndex = orderIndex;
    }

    public Long getCityId() { return cityId; }
    public void setCityId(Long cityId) { this.cityId = cityId; }

    public Long getId() { return poiId; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public double getLat() { return lat; }
    public double getLng() { return lng; }

    @Override
    public String toString() { return name; }
}
