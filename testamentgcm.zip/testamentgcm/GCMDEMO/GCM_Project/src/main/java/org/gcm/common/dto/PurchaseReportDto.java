package org.gcm.common.dto;

import java.io.Serializable;

public class PurchaseReportDto implements Serializable {
    private Long purchaseId;
    private String userName;
    private String tourName;
    private String cityName;
    private double price;
    private String purchaseDate;

    public PurchaseReportDto(Long purchaseId, String userName, String tourName, String cityName, double price, String purchaseDate) {
        this.purchaseId = purchaseId;
        this.userName = userName;
        this.tourName = tourName;
        this.cityName = cityName;
        this.price = price;
        this.purchaseDate = purchaseDate;
    }

    public Long getPurchaseId() { return purchaseId; }
    public String getUserName() { return userName; }
    public String getTourName() { return tourName; }
    public String getCityName() { return cityName; }
    public double getPrice() { return price; }
    public String getPurchaseDate() { return purchaseDate; }
}
