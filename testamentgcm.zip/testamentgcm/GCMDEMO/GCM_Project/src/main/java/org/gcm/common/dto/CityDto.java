package org.gcm.common.dto;

import java.io.Serializable;

public class CityDto implements Serializable {
    private Long cityId;
    private String cityName;
    private String description;
    private int mapsCount;
    private double oneTimePrice;
    private String currency;

    public CityDto(Long cityId, String cityName, String description, int mapsCount, double oneTimePrice, String currency) {
        this.cityId = cityId;
        this.cityName = cityName;
        this.description = description;
        this.mapsCount = mapsCount;
        this.oneTimePrice = oneTimePrice;
        this.currency = currency;
    }

    public Long getCityId() { return cityId; }
    public String getCityName() { return cityName; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public int getMapsCount() { return mapsCount; }
    public double getOneTimePrice() { return oneTimePrice; }
    public String getCurrency() { return currency; }

    @Override
    public String toString() {
        return cityName;
    }
}
