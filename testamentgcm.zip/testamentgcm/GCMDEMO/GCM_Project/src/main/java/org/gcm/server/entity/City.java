package org.gcm.server.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "city")
public class City {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "city_id")
    private Long cityId;

    @Column(name = "city_name", nullable = false)
    private String cityName;

    @Column(name = "city_desc")
    private String cityDesc;

    public City() {}

    public City(String cityName, String cityDesc) {
        this.cityName = cityName;
        this.cityDesc = cityDesc;
    }

    public Long getCityId() { return cityId; }
    public void setCityId(Long cityId) { this.cityId = cityId; }

    public String getCityName() { return cityName; }
    public void setCityName(String cityName) { this.cityName = cityName; }

    public String getCityDesc() { return cityDesc; }
    public void setCityDesc(String cityDesc) { this.cityDesc = cityDesc; }
}
