package org.gcm.server.service;
import org.gcm.server.entity.MapEntity;
import org.gcm.common.dto.CityDto;
import org.gcm.common.dto.PoiDto;
import org.gcm.common.dto.TourDto;
import org.gcm.server.HibernateUtil;
import org.gcm.server.db.GcmRepository;
import org.gcm.server.entity.*;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.ArrayList;
import java.util.List;

public class CatalogService {
    private static CatalogService instance;
    private GcmRepository repository;

    private CatalogService() {
        repository = GcmRepository.getInstance();
    }

    public static CatalogService getInstance() {
        if (instance == null) instance = new CatalogService();
        return instance;
    }

    public List<CityDto> getCatalog() {
        List<City> cities = repository.findAll(City.class);
        List<CityDto> dtos = new ArrayList<>();
        for (City c : cities) {
            dtos.add(new CityDto(c.getCityId(), c.getCityName(), c.getCityDesc(), 0, 0.0, "$"));
        }
        return dtos;
    }

    public List<TourDto> getCityTours(Long cityId, Long userId) {
        List<Tour> tours = repository.findToursByCity(cityId);
        List<TourDto> dtos = new ArrayList<>();

        boolean isPrivileged = false;
        if (userId != null) {
            AppUser user = repository.findById(AppUser.class, userId);
            if (user != null && !user.getRole().equals("CUSTOMER")) isPrivileged = true;
        }

        for (Tour t : tours) {
            TourDto dto = new TourDto(t.getTourId(), t.getCityId(), t.getTourName(), t.getDescription(), t.getPrice(), "2h");

            boolean purchased = isPrivileged || (userId != null && repository.hasPurchased(userId, t.getTourId()));
            dto.setPurchased(purchased);

            List<String> names = new ArrayList<>();
            List<Long> ids = new ArrayList<>();

            if (t.getStops() != null) {
                for (TourStop stop : t.getStops()) {
                    if (stop.getPoi() != null) {
                        names.add(stop.getPoi().getPoiName());
                        ids.add(stop.getPoi().getPoiId());
                    }
                }
            }

            dto.setPoiNames(names);
            dto.setPoiIds(ids);

            dtos.add(dto);
        }
        return dtos;
    }

    public void addTour(TourDto tourDto) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();

            Tour tourEntity = new Tour();
            tourEntity.setTourName(tourDto.getTourName());
            tourEntity.setDescription(tourDto.getDescription());
            tourEntity.setCityId(tourDto.getCityId());
            tourEntity.setPrice(tourDto.getPrice());

            if (tourDto.getPoiIds() != null && !tourDto.getPoiIds().isEmpty()) {
                int order = 1;
                for (Long poiId : tourDto.getPoiIds()) {
                    Poi poi = session.get(Poi.class, poiId);
                    if (poi != null) {

                        TourStop stop = new TourStop();
                        stop.setTour(tourEntity);
                        stop.setPoi(poi);
                        stop.setStopOrder(order++);
                        stop.setRecommendedMinutes(30);

                        tourEntity.getStops().add(stop);
                    }
                }
            }

            session.save(tourEntity);

            tx.commit();
            System.out.println("✅ Tour Saved with " + tourEntity.getStops().size() + " stops.");

        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public List<PoiDto> getCityPois(Long cityId) {
        List<Poi> pois = repository.findAll(Poi.class);
        List<PoiDto> dtos = new ArrayList<>();
        for (Poi p : pois) {
            if (p.getCityId().equals(cityId)) {
                dtos.add(new PoiDto(p.getPoiId(), p.getPoiName(), p.getDescription(), p.getLat(), p.getLng(), 0));
            }
        }
        return dtos;
    }

   public void addCity(CityDto cityDto) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            City cityEntity = new City();
            cityEntity.setCityName(cityDto.getCityName());
            cityEntity.setCityDesc(cityDto.getDescription());
            session.save(cityEntity);
            tx.commit();
            System.out.println("✅ City added: " + cityEntity.getCityName());
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public void addPoi(PoiDto poiDto) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();

            Poi poiEntity = new Poi();
            poiEntity.setPoiName(poiDto.getName());
            poiEntity.setDescription(poiDto.getDescription());
            poiEntity.setLat(poiDto.getLat());
            poiEntity.setLng(poiDto.getLng());

            City city = session.get(City.class, poiDto.getCityId());
            if (city != null) {
                poiEntity.setCityId(city.getCityId());
            }

            PoiCategory defaultCategory = session.get(PoiCategory.class, 1L);
            if (defaultCategory == null) {
                defaultCategory = new PoiCategory();

                defaultCategory.setCategoryName("General");
                session.save(defaultCategory);
            }
            poiEntity.setCategory(defaultCategory);

            List<MapEntity> maps = session.createQuery("FROM MapEntity", MapEntity.class)
                    .setMaxResults(1)
                    .list();

            MapEntity mapToUse;
            if (!maps.isEmpty()) {
                mapToUse = maps.get(0);
            } else {
                mapToUse = new MapEntity();
                mapToUse.setProvider("Google");
                mapToUse.setZoom(10);
                session.save(mapToUse);
            }

            poiEntity.setMap(mapToUse);

            session.save(poiEntity);

            tx.commit();
            System.out.println("✅ POI Added successfully!");

        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
}
