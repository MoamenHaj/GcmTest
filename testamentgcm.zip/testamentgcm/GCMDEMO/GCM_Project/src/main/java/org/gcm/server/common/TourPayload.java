package org.gcm.server.common;

import java.io.Serializable;
import java.util.List;

public class TourPayload implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long cityId;
    private String tourName;
    private String description;
    private double price;
    private List<Long> poiIds;

    public TourPayload(Long cityId, String tourName, String description, double price, List<Long> poiIds) {
        this.cityId = cityId;
        this.tourName = tourName;
        this.description = description;
        this.price = price;
        this.poiIds = poiIds;
    }

    public Long getCityId() { return cityId; }
    public String getTourName() { return tourName; }
    public String getDescription() { return description; }
    public double getPrice() { return price; }
    public List<Long> getPoiIds() { return poiIds; }
}
