package org.gcm.server.service;

import org.gcm.common.dto.MapDto;
import org.gcm.common.dto.MapResponseDto;
import org.gcm.common.dto.PoiDto;
import org.gcm.server.db.GcmRepository;
import org.gcm.server.entity.*;
import java.util.ArrayList;
import java.util.List;

public class MapService {
    private static MapService instance;
    private GcmRepository repository;

    private MapService() { this.repository = GcmRepository.getInstance(); }

    public static MapService getInstance() {
        if (instance == null) instance = new MapService();
        return instance;
    }

    public MapResponseDto getMapForTour(long tourId, AppUser user) throws IllegalAccessException {

        Tour tour = repository.findById(Tour.class, tourId);
        if (tour == null) throw new IllegalArgumentException("Tour not found");

        boolean isAuthorized = false;
        if (user != null) {

            AppUser dbUser = repository.findById(AppUser.class, user.getUserId());
            String role = (dbUser != null) ? dbUser.getRole() : "CUSTOMER";

            if (!"CUSTOMER".equalsIgnoreCase(role)) {
                isAuthorized = true;
            } else {
                isAuthorized = repository.hasPurchased(user.getUserId(), tourId);
            }
        }

        if (!isAuthorized) throw new IllegalAccessException("Purchase required");

        MapEntity mapEntity = tour.getMap();
        MapDto mapDto = (mapEntity != null) ?
                new MapDto(mapEntity.getId(), mapEntity.getProvider(), mapEntity.getZoom()) : null;

        List<PoiDto> poiDtos = new ArrayList<>();

        if (tour.getStops() != null) {
            for (TourStop stop : tour.getStops()) {
                Poi p = stop.getPoi();
                poiDtos.add(new PoiDto(p.getPoiId(), p.getPoiName(), p.getDescription(), p.getLat(), p.getLng(), stop.getStopOrder()));
            }
        }
        return new MapResponseDto(mapDto, poiDtos);
    }

    public boolean purchaseMap(long tourId, AppUser user) {
        if (user == null) return false;

        if (repository.hasPurchased(user.getUserId(), tourId)) return true;

        Purchase p = new Purchase(user.getUserId(), tourId);
        return repository.save(p);
    }
}
