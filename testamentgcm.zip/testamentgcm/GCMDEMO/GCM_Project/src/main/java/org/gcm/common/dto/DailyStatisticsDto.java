package org.gcm.common.dto;

import java.io.Serializable;
import java.time.LocalDate;

public class DailyStatisticsDto implements Serializable {
    private LocalDate date;
    private long totalLogins;
    private long totalToursViewed;
    private long totalToursPurchased;
    private long totalRequestsCreated;
    private long totalRequestsApproved;
    private double totalRevenue;

    public DailyStatisticsDto(LocalDate date, long totalLogins, long totalToursViewed, long totalToursPurchased, long totalRequestsCreated, long totalRequestsApproved, double totalRevenue) {
        this.date = date;
        this.totalLogins = totalLogins;
        this.totalToursViewed = totalToursViewed;
        this.totalToursPurchased = totalToursPurchased;
        this.totalRequestsCreated = totalRequestsCreated;
        this.totalRequestsApproved = totalRequestsApproved;
        this.totalRevenue = totalRevenue;
    }

    public LocalDate getDate() { return date; }
    public long getTotalLogins() { return totalLogins; }
    public long getTotalToursViewed() { return totalToursViewed; }
    public long getTotalToursPurchased() { return totalToursPurchased; }
    public long getTotalRequestsCreated() { return totalRequestsCreated; }
    public long getTotalRequestsApproved() { return totalRequestsApproved; }
    public double getTotalRevenue() { return totalRevenue; }
}
