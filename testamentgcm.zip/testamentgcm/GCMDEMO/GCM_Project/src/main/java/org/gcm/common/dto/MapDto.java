package org.gcm.common.dto;

import java.io.Serializable;

public class MapDto implements Serializable {
    private Long id;
    private String provider;
    private int zoom;

    public MapDto(Long id, String provider, int zoom) {
        this.id = id;
        this.provider = provider;
        this.zoom = zoom;
    }

    public Long getId() { return id; }
    public String getProvider() { return provider; }
    public int getZoom() { return zoom; }
}
