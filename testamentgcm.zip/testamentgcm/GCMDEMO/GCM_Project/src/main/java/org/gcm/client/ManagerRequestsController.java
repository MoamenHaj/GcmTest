package org.gcm.client;

import javafx.application.Platform;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.gcm.common.Message;
import org.gcm.common.dto.ModificationRequestDto;
import org.gcm.common.enums.MessageType;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.List;

public class ManagerRequestsController {

    @FXML private TableView<ModificationRequestDto> tableRequests;
    @FXML private TableColumn<ModificationRequestDto, Long> colId;
    @FXML private TableColumn<ModificationRequestDto, String> colWorker;
    @FXML private TableColumn<ModificationRequestDto, String> colDesc;

    @FXML private TableColumn<ModificationRequestDto, String> colDate;
    @FXML private TableColumn<ModificationRequestDto, String> colStatus;

    @FXML private Button btnApprove;
    @FXML private Button btnReject;
    @FXML private Label lblStatus;

    private ObservableList<ModificationRequestDto> requestsList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {

        if(colId != null) colId.setCellValueFactory(cell -> new SimpleLongProperty(cell.getValue().getRequestId()).asObject());
        if(colWorker != null) colWorker.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getWorkerName()));
        if(colDesc != null) colDesc.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getDescription()));

        TableColumn<ModificationRequestDto, String> statusCol = (colDate != null) ? colDate : colStatus;
        if (statusCol != null) {
            statusCol.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getStatus()));
        }

        tableRequests.setItems(requestsList);
        loadPendingRequests();
    }

    private void loadPendingRequests() {
        new Thread(() -> {
            try {
                GcmClient client = GcmClient.getInstance();
                client.sendRequest(new Message(MessageType.GET_PENDING_REQUESTS, null));
                Object response = client.waitForResponse();

                System.out.println("DEBUG: Client received response type: " + (response == null ? "NULL" : response.getClass().getName()));

                List<ModificationRequestDto> data = null;

                if (response instanceof Message) {
                    Message msg = (Message) response;
                    if (msg.getData() instanceof List) {
                        data = (List<ModificationRequestDto>) msg.getData();
                    }
                }
                else if (response instanceof List) {

                    System.out.println("✅ Received Raw List directly!");
                    data = (List<ModificationRequestDto>) response;
                }

                if (data != null) {
                    List<ModificationRequestDto> finalData = data;
                    Platform.runLater(() -> {
                        requestsList.setAll(finalData);
                        lblStatus.setText("Loaded " + finalData.size() + " requests.");
                    });
                } else {
                    System.err.println("❌ Unknown response type: " + (response == null ? "NULL" : response.getClass().getName()));
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    @FXML public void handleApprove() { processRequest(MessageType.APPROVE_REQUEST); }
    @FXML public void handleReject() { processRequest(MessageType.REJECT_REQUEST); }

    private void processRequest(MessageType type) {
        ModificationRequestDto selected = tableRequests.getSelectionModel().getSelectedItem();
        if (selected == null) return;
        new Thread(() -> {
            try {
                GcmClient.getInstance().sendRequest(new Message(type, selected.getRequestId()));
                Object response = GcmClient.getInstance().waitForResponse();

                boolean success = false;
                if (response instanceof Message) {
                    success = (boolean) ((Message) response).getData();
                } else if (response instanceof Boolean) {
                    success = (Boolean) response;
                }

                if (success) {
                    Platform.runLater(() -> {
                        lblStatus.setText("Request processed successfully.");
                        loadPendingRequests();
                    });
                } else {
                    Platform.runLater(() -> lblStatus.setText("Failed to process request."));
                }
            } catch (Exception e) { e.printStackTrace(); }
        }).start();
    }

    @FXML public void handleBack() {
        try {
            Stage stage = (Stage) tableRequests.getScene().getWindow();
            stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/org/gcm/client/CatalogView.fxml"))));
        } catch (IOException e) { e.printStackTrace(); }
    }
}
