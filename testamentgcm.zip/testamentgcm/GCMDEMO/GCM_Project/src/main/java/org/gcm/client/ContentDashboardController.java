package org.gcm.client;

import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import org.gcm.common.Message;
import org.gcm.common.dto.CityDto;
import org.gcm.common.dto.ModificationRequestDto;
import org.gcm.common.enums.MessageType;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

public class ContentDashboardController {

    @FXML private TableView<CityDto> tableCities;
    @FXML private TableColumn<CityDto, String> colName;
    @FXML private TableColumn<CityDto, String> colVersion;
    @FXML private TableColumn<CityDto, String> colStatus;
    @FXML private TableColumn<CityDto, Void> colAction;
    @FXML private Button btnStats;

    @FXML private HBox boxPending;
    @FXML private Label lblPendingCount;

    @FXML
    public void initialize() {

        colName.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getCityName()));
        colVersion.setCellValueFactory(cell -> new SimpleStringProperty("v1.0"));
        colStatus.setCellValueFactory(cell -> new SimpleStringProperty("Active"));

        colAction.setCellFactory(param -> new TableCell<>() {
            private final Button btnManage = new Button("Manage");
            private final Button btnDelete = new Button("Delete");
            private final HBox pane = new HBox(10, btnManage, btnDelete);

            {

                btnManage.setStyle("-fx-background-color: #2962ff; -fx-text-fill: white; -fx-cursor: hand;");
                btnManage.setOnAction(event -> handleManageCity(getTableView().getItems().get(getIndex())));

                btnDelete.setStyle("-fx-background-color: #ef5350; -fx-text-fill: white; -fx-cursor: hand;");
                btnDelete.setOnAction(event -> handleDeleteCity(getTableView().getItems().get(getIndex())));
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : pane);
            }
        });

        String userRole = ClientSession.getInstance().getUser().getRole();
        if ("ADMIN".equalsIgnoreCase(userRole) || "Manager".equalsIgnoreCase(userRole)) {
            btnStats.setVisible(true);
            btnStats.setManaged(true);

            btnStats.setOnAction(e -> handleStats());

            fetchPendingCountAndCities();
        } else {
            btnStats.setVisible(false);
            btnStats.setManaged(false);

            boxPending.setVisible(false);
            boxPending.setManaged(false);

            loadCitiesFromServer();
        }
    }

    private void fetchPendingCountAndCities() {
        new Thread(() -> {
            try {

                GcmClient.getInstance().sendRequest(new Message(MessageType.GET_PENDING_REQUESTS, null));
                Object response = GcmClient.getInstance().waitForResponse();

                List<ModificationRequestDto> requests = null;
                if (response instanceof Message && ((Message)response).getType() == MessageType.GET_PENDING_REQUESTS_RESPONSE) {
                    requests = (List<ModificationRequestDto>) ((Message)response).getData();
                } else if (response instanceof List) {
                    requests = (List<ModificationRequestDto>) response;
                }

                if (requests != null) {
                    final int count = requests.size();
                    Platform.runLater(() -> {
                        if (count > 0) {
                            lblPendingCount.setText("There are " + count + " items waiting for approval.");
                            boxPending.setVisible(true);
                            boxPending.setManaged(true);
                        } else {
                            boxPending.setVisible(false);
                            boxPending.setManaged(false);
                        }
                    });
                }

                loadCitiesInternal();

            } catch (Exception e) { e.printStackTrace(); }
        }).start();
    }

    @FXML
    public void handleAddCity() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Add City");
        dialog.setHeaderText("Create New City");
        dialog.setContentText("Enter City Name:");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(name -> {
            if (name.trim().isEmpty()) return;
            new Thread(() -> {
                try {

                    GcmClient.getInstance().sendRequest(new Message(MessageType.ADD_CITY_REQUEST, name));

                    Thread.sleep(500);
                    loadCitiesFromServer();
                } catch (Exception e) { e.printStackTrace(); }
            }).start();
        });
    }

    private void handleDeleteCity(CityDto city) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Delete " + city.getCityName() + "?", ButtonType.YES, ButtonType.NO);
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                new Thread(() -> {
                    try {

                        GcmClient.getInstance().sendRequest(new Message(MessageType.DELETE_CITY_REQUEST, city.getCityId()));
                        Thread.sleep(500);
                        loadCitiesFromServer();
                    } catch (Exception e) { e.printStackTrace(); }
                }).start();
            }
        });
    }

    private void loadCitiesFromServer() {
        new Thread(this::loadCitiesInternal).start();
    }

    private void loadCitiesInternal() {
        try {
            GcmClient.getInstance().sendRequest(new Message(MessageType.GET_CATALOG_REQUEST, null));

            Object response = GcmClient.getInstance().waitForResponse();

            if (response instanceof java.util.List) {
                List<CityDto> cities = (List<CityDto>) response;
                Platform.runLater(() -> tableCities.setItems(FXCollections.observableArrayList(cities)));
            }

            else if (response instanceof Message) {
                Message msg = (Message) response;
                if (msg.getData() instanceof List) {
                    List<CityDto> cities = (List<CityDto>) msg.getData();
                    Platform.runLater(() -> tableCities.setItems(FXCollections.observableArrayList(cities)));
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void handleManageCity(CityDto city) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/gcm/client/CityEditView.fxml"));
            Scene scene = new Scene(loader.load());
            CityEditController controller = loader.getController();
            controller.setCityData(city);
            Stage stage = (Stage) tableCities.getScene().getWindow();
            stage.setScene(scene);
        } catch (IOException e) { e.printStackTrace(); }
    }

    @FXML public void handleBack() {
        try {
            Stage stage = (Stage) tableCities.getScene().getWindow();
            stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/org/gcm/client/CatalogView.fxml"))));
        } catch (IOException e) { e.printStackTrace(); }
    }

    public void handleStats() {
        try {
            Stage stage = (Stage) tableCities.getScene().getWindow();
            stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/org/gcm/client/ManagerStatsView.fxml"))));
        } catch (IOException e) { e.printStackTrace(); }
    }
}
