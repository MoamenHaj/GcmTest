package org.gcm.server;

import org.gcm.server.HibernateUtil;
import org.gcm.server.entity.Tour;
import org.hibernate.Session;

public class HibernateTest {
    public static void main(String[] args) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();

        session.createQuery("from Tour", Tour.class)
                .setMaxResults(1)
                .list();

        session.getTransaction().commit();
        session.close();

        System.out.println("Hibernate works!");
    }
}
