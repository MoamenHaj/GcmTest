package org.gcm.client;

import javafx.application.Platform;
import javafx.geometry.Point2D;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polyline;
import javafx.scene.text.Text;
import org.gcm.common.dto.PoiDto;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MapView extends Pane {
    private static final int TILE_SIZE = 256;
    private int zoom = 14;
    private double centerLat = 31.0461;
    private double centerLng = 34.8516;

    private final Map<String, Image> tileCache = new HashMap<>();
    private final ExecutorService executor = Executors.newFixedThreadPool(4);
    private final Pane tilesLayer = new Pane();
    private final Pane overlayLayer = new Pane();

    private double dragStartX, dragStartY;
    private double centerPixelX, centerPixelY;

    public MapView() {
        getChildren().addAll(tilesLayer, overlayLayer);

        setClip(new javafx.scene.shape.Rectangle(800, 600));
        layoutBoundsProperty().addListener((obs, oldVal, newVal) -> {
            setClip(new javafx.scene.shape.Rectangle(newVal.getWidth(), newVal.getHeight()));
            updateMap();
        });

        setOnMousePressed(e -> {
            dragStartX = e.getX();
            dragStartY = e.getY();
        });

        setOnMouseDragged(e -> {
            double dx = e.getX() - dragStartX;
            double dy = e.getY() - dragStartY;
            centerPixelX -= dx;
            centerPixelY -= dy;
            dragStartX = e.getX();
            dragStartY = e.getY();
            updateMap();
        });

        setOnScroll(e -> {
            if (e.getDeltaY() > 0) zoomIn();
            else zoomOut();
            e.consume();
        });

        updateCenterPixels();
    }

    private void updateCenterPixels() {
        centerPixelX = lonToX(centerLng, zoom);
        centerPixelY = latToY(centerLat, zoom);
    }

    public void setCenter(double lat, double lng) {
        this.centerLat = lat;
        this.centerLng = lng;
        updateCenterPixels();
        updateMap();
    }

    public void setZoom(int z) {
        this.zoom = Math.max(1, Math.min(19, z));
        updateCenterPixels();
        updateMap();
    }

    private void zoomIn() { setZoom(zoom + 1); }
    private void zoomOut() { setZoom(zoom - 1); }

    public void setPois(List<PoiDto> pois) {
        overlayLayer.getChildren().clear();
        if (pois == null || pois.isEmpty()) return;

        PoiDto first = pois.get(0);
        System.out.println("DEBUG: Centering map on POI: " + first.getName() + " (" + first.getLat() + ", " + first.getLng() + ")");
        setCenter(first.getLat(), first.getLng());

        Polyline line = new Polyline();
        line.setStroke(Color.BLUE);
        line.setStrokeWidth(3);

        for (PoiDto p : pois) {
            double x = lonToX(p.getLng(), zoom);
            double y = latToY(p.getLat(), zoom);

        }

        this.currentPois = pois;
        updateMap();
    }

    private List<PoiDto> currentPois;

    private void updateMap() {
        tilesLayer.getChildren().clear();
        overlayLayer.getChildren().clear();

        double width = getWidth();
        double height = getHeight();
        if (width == 0 || height == 0) return;

        double left = centerPixelX - width / 2;
        double top = centerPixelY - height / 2;

        int startTileX = (int) Math.floor(left / TILE_SIZE);
        int startTileY = (int) Math.floor(top / TILE_SIZE);
        int endTileX = (int) Math.floor((left + width) / TILE_SIZE);
        int endTileY = (int) Math.floor((top + height) / TILE_SIZE);

        for (int x = startTileX; x <= endTileX; x++) {
            for (int y = startTileY; y <= endTileY; y++) {
                int maxTile = 1 << zoom;
                int tileX = (x % maxTile + maxTile) % maxTile;
                int tileY = y;

                if (tileY < 0 || tileY >= maxTile) continue;

                String url = "https://tile.openstreetmap.org/" + zoom + "/" + tileX + "/" + tileY + ".png";

                ImageView iv = new ImageView();
                iv.setX(x * TILE_SIZE - left);
                iv.setY(y * TILE_SIZE - top);

                loadTile(url, iv);
                tilesLayer.getChildren().add(iv);
            }
        }

        if (currentPois != null) {
            Polyline line = new Polyline();
            line.setStroke(Color.BLUE);
            line.setStrokeWidth(3);

            for (PoiDto p : currentPois) {
                double worldX = lonToX(p.getLng(), zoom);
                double worldY = latToY(p.getLat(), zoom);

                double screenX = worldX - left;
                double screenY = worldY - top;

                line.getPoints().addAll(screenX, screenY);

                Circle marker = new Circle(screenX, screenY, 5, Color.RED);
                marker.setStroke(Color.WHITE);

                Text label = new Text(screenX + 8, screenY, p.getName());
                label.setStyle("-fx-font-weight: bold; -fx-fill: black; -fx-stroke: white; -fx-stroke-width: 0.5px;");

                overlayLayer.getChildren().addAll(marker, label);
            }
            overlayLayer.getChildren().add(0, line);
        }

        Text attribution = new Text(10, height - 10, "© OpenStreetMap contributors");
        attribution.setStyle("-fx-font-size: 10px;");
        overlayLayer.getChildren().add(attribution);
    }

    private double lonToX(double lon, int zoom) {
        return (lon + 180) / 360 * (1 << zoom) * TILE_SIZE;
    }

    private double latToY(double lat, int zoom) {
        double latRad = Math.toRadians(lat);
        return (1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2 * (1 << zoom) * TILE_SIZE;
    }

    private void loadTile(String url, ImageView iv) {
        if (tileCache.containsKey(url)) {
            iv.setImage(tileCache.get(url));
            return;
        }

        executor.submit(() -> {
            try {

                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setRequestProperty("User-Agent", "GCM-Client/1.0");

                try (InputStream in = conn.getInputStream()) {
                    Image img = new Image(in);
                    Platform.runLater(() -> {
                        tileCache.put(url, img);
                        iv.setImage(img);
                    });
                }
            } catch (Exception e) {
                System.err.println("Failed to load tile: " + url);
            }
        });
    }
}
