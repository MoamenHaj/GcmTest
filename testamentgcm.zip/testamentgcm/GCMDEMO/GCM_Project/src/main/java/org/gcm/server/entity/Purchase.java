package org.gcm.server.entity;

import jakarta.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "purchase")
public class Purchase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "purchase_id")
    private Long purchaseId;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "tour_id")
    private Long tourId;

    @Column(name = "purchase_date")
    private Timestamp purchaseDate;

    public Purchase() {}

    public Purchase(Long userId, Long tourId) {
        this.userId = userId;
        this.tourId = tourId;
        this.purchaseDate = new Timestamp(System.currentTimeMillis());
    }

    public Long getPurchaseId() { return purchaseId; }
    public void setPurchaseId(Long purchaseId) { this.purchaseId = purchaseId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public Long getTourId() { return tourId; }
    public void setTourId(Long tourId) { this.tourId = tourId; }

    public Timestamp getPurchaseDate() { return purchaseDate; }
    public void setPurchaseDate(Timestamp purchaseDate) { this.purchaseDate = purchaseDate; }
}
