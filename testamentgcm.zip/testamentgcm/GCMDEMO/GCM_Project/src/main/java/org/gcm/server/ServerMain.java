package org.gcm.server;

import java.io.IOException;

public class ServerMain {
    public static void main(String[] args) {
        int port = 5555;

        GcmServer server = new GcmServer(port);

        try {
            server.listen();
            System.out.println("🚀 Server is running and listening on port " + port);
            System.out.println("Waiting for clients...");
        } catch (IOException e) {
            System.err.println("❌ Could not listen on port " + port);
            e.printStackTrace();
        }
    }
}
