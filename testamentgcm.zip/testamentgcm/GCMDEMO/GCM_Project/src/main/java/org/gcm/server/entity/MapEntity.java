package org.gcm.server.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "map")
public class MapEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "provider")
    private String provider;

    @Column(name = "zoom")
    private int zoom;

    public MapEntity() {}

    public MapEntity(String provider, int zoom) {
        this.provider = provider;
        this.zoom = zoom;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getProvider() { return provider; }
    public void setProvider(String provider) { this.provider = provider; }

    public int getZoom() { return zoom; }
    public void setZoom(int zoom) { this.zoom = zoom; }
}
