package org.gcm.server.entity;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "tour_stop")
public class TourStop implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "tour_id", nullable = false)
    private Tour tour;

    @ManyToOne
    @JoinColumn(name = "poi_id", nullable = false)
    private Poi poi;

    @Column(name = "stop_order", nullable = false)
    private int stopOrder;

    @Column(name = "recommended_minutes")
    private int recommendedMinutes;

    public TourStop() {}

    public TourStop(Tour tour, Poi poi, int stopOrder, int recommendedMinutes) {
        this.tour = tour;
        this.poi = poi;
        this.stopOrder = stopOrder;
        this.recommendedMinutes = recommendedMinutes;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Tour getTour() { return tour; }
    public void setTour(Tour tour) { this.tour = tour; }

    public Poi getPoi() { return poi; }
    public void setPoi(Poi poi) { this.poi = poi; }

    public int getStopOrder() { return stopOrder; }
    public void setStopOrder(int stopOrder) { this.stopOrder = stopOrder; }

    public int getRecommendedMinutes() { return recommendedMinutes; }
    public void setRecommendedMinutes(int recommendedMinutes) { this.recommendedMinutes = recommendedMinutes; }
}
