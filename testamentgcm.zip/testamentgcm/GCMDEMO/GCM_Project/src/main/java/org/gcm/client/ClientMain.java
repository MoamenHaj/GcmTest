package org.gcm.client;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class ClientMain extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {

        try {
            GcmClient.initialize("localhost", 5555);
        } catch (IOException e) {
            System.err.println("Could not connect to server!");
            e.printStackTrace();
            return;
        }

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/gcm/client/LoginView.fxml"));
        Parent root = loader.load();

        primaryStage.setTitle("GCM Client Prototype");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }

    @Override
    public void stop() throws Exception {
        if (GcmClient.getInstance() != null) {
            GcmClient.getInstance().closeConnection();
        }
        super.stop();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
