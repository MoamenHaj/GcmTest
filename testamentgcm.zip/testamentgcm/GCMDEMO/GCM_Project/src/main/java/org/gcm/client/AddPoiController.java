package org.gcm.client;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.gcm.common.Message;
import org.gcm.common.dto.CityDto;
import org.gcm.common.dto.PoiDto;
import org.gcm.common.enums.MessageType;

public class AddPoiController {

    @FXML private TextField tfName, tfCityId, tfLat, tfLng;
    @FXML private TextArea taDesc;
    @FXML private Label lblStatus;

    private Long passedCityId;
    private PoiDto editingPoi;

    public void setPoiData(CityDto city, PoiDto poi) {
        if (city != null) {
            this.passedCityId = city.getCityId();
            if (tfCityId != null) {
                tfCityId.setText(String.valueOf(city.getCityId()));
                tfCityId.setDisable(true);
            }
        }
        if (poi != null) {
            this.editingPoi = poi;
            if (tfName != null) tfName.setText(poi.getName());
            if (taDesc != null) taDesc.setText(poi.getDescription());
            if (tfLat != null) tfLat.setText(String.valueOf(poi.getLat()));
            if (tfLng != null) tfLng.setText(String.valueOf(poi.getLng()));
            if (lblStatus != null) lblStatus.setText("Editing: " + poi.getName());
        }
    }

    @FXML
    public void handleSubmit() {
        try {
            String name = tfName.getText();
            String desc = taDesc.getText();

            Long cityId;
            if (tfCityId.getText().isEmpty() && passedCityId != null) {
                cityId = passedCityId;
            } else {
                cityId = Long.parseLong(tfCityId.getText());
            }

            double lat = tfLat.getText().isEmpty() ? 0.0 : Double.parseDouble(tfLat.getText());
            double lng = tfLng.getText().isEmpty() ? 0.0 : Double.parseDouble(tfLng.getText());

            Long idToSend = (editingPoi != null) ? editingPoi.getId() : 0L;

            PoiDto poiToSend = new PoiDto(idToSend, name, desc, lat, lng, 0);
            poiToSend.setCityId(cityId);

            Message msg = new Message(MessageType.ADD_POI_REQUEST, poiToSend);
            GcmClient.getInstance().sendRequest(msg);

            lblStatus.setText("Request Sent!");

        } catch (NumberFormatException e) {
            lblStatus.setText("Invalid ID or Coordinates");
        }
    }

    @FXML
    public void handleBack() {
        try {

            Stage stage = null;

            if (lblStatus != null && lblStatus.getScene() != null) {
                stage = (Stage) lblStatus.getScene().getWindow();
            } else if (tfName != null && tfName.getScene() != null) {
                stage = (Stage) tfName.getScene().getWindow();
            }

            if (stage != null) {
                stage.close();
            } else {
                System.err.println("❌ Could not find stage to close!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
