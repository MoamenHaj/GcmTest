package org.gcm.server.db;

import org.gcm.server.entity.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import java.util.List;

public class GcmRepository {
    private static GcmRepository instance;
    private SessionFactory sessionFactory;

    private GcmRepository() {
        try {
            sessionFactory = new Configuration().configure().buildSessionFactory();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static GcmRepository getInstance() {
        if (instance == null) instance = new GcmRepository();
        return instance;
    }

    public <T> boolean save(T entity) {
        Transaction tx = null;
        try (Session session = sessionFactory.openSession()) {
            tx = session.beginTransaction();
            session.persist(entity);
            tx.commit();
            return true;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return false;
        }
    }

    public <T> boolean update(T entity) {
        Transaction tx = null;
        try (Session session = sessionFactory.openSession()) {
            tx = session.beginTransaction();
            session.update(entity);
            tx.commit();
            return true;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return false;
        }
    }

    public <T> boolean delete(Object entity) {
        Transaction tx = null;
        try (Session session = sessionFactory.openSession()) {
            tx = session.beginTransaction();
            session.remove(entity);
            tx.commit();
            return true;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return false;
        }
    }

    public <T> T findById(Class<T> type, Long id) {
        try (Session session = sessionFactory.openSession()) {
            return session.get(type, id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public <T> List<T> findAll(Class<T> type) {
        try (Session session = sessionFactory.openSession()) {
            return session.createQuery("FROM " + type.getSimpleName(), type).list();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public AppUser findUserByUsername(String username) {
        try (Session session = sessionFactory.openSession()) {
            return session.createQuery("FROM AppUser WHERE username = :u", AppUser.class)
                    .setParameter("u", username)
                    .uniqueResult();
        }
    }

    public List<Tour> findToursByCity(Long cityId) {
        try (Session session = sessionFactory.openSession()) {
            return session.createQuery("FROM Tour WHERE cityId = :cid", Tour.class)
                    .setParameter("cid", cityId)
                    .list();
        }
    }

    public List<ModificationRequest> findPendingRequests() {
        try (Session session = sessionFactory.openSession()) {
            return session.createQuery("FROM ModificationRequest WHERE status = 'PENDING'", ModificationRequest.class).list();
        }
    }

    public boolean hasPurchased(Long userId, Long tourId) {
        try (Session session = sessionFactory.openSession()) {
            Long count = session.createQuery("SELECT count(p) FROM Purchase p WHERE p.userId = :uid AND p.tourId = :tid", Long.class)
                    .setParameter("uid", userId)
                    .setParameter("tid", tourId)
                    .uniqueResult();
            return count > 0;
        } catch (Exception e) { return false; }
    }

    public Session openSession() {
        return sessionFactory.openSession();
    }
}
